<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PageContent;
use Laravel\Cashier\Cashier;
use App\Models\PricingModel;
use Stripe;
class HomeController extends Controller
{
    public function __construct(){
        parent::__construct();
       
    }
  
    public function index(Request $request)
    {   
        
        $this->data['pakage']  = PricingModel::where('id','>','0')->first();
        $this->data['page_content'] = PageContent::where('id','>','0')->first();
        return view('home.index',$this->data);
        
    }

       
    
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe;
use App\Models\userSubscriptionModel;
use App\Models\PricingModel;
class Payment extends Controller
{   
    public function subscription(Request $request){
        $currency = "USD"; 
        $token = $request->stripeToken;
        $plans = $this->plans();
         // Plan info 
        $planID =1;   // $_POST['subscr_plan']
        $pakage = PricingModel::where('duration',$request->input('duration'))->first();
        $pakage->price = $this->percentage($pakage->discount,$pakage->price);
        $planInfo = $plans[$planID]; 
        $planName = $pakage->duration.'ly Subscription'; 
        $planPrice = $pakage->price; 
        $planInterval = $pakage->duration;
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        // $data=\Stripe\Charge::create(array(
        // 	"amount"=>1000,
        // 	"currency"=>"usd",
        // 	"description"=>"Programming with Vishal Desc",
        // 	"source"=>$token,
        // ));
        // Add customer to stripe 
        try {  
            $customer = \Stripe\Customer::create(array( 
                'email' => 'aqib5452@gmail.com', 
                'source'  => $token 
            )); 
        }catch(Exception $e) {  
            $api_error = $e->getMessage();  
        } 
     
    if(empty($api_error) && $customer){  
        // Convert price to cents 
        $priceCents = round($planPrice*100); 
     
        // Create a plan 
        try { 
            $plan = \Stripe\Plan::create(array( 
                "product" => [ 
                    "name" => $planName 
                ], 
                "amount" => $priceCents, 
                "currency" => $currency, 
                "interval" => $planInterval, 
                "interval_count" => 1 
            )); 
        }catch(Exception $e) { 
            $api_error = $e->getMessage(); 
        } 
         
        if(empty($api_error) && $plan){ 
			// Creates a new subscription 
            try { 
                $subscription = \Stripe\Subscription::create(array( 
                    "customer" => $customer->id, 
                    "items" => array( 
                        array( 
                            "plan" => $plan->id, 
                        ), 
                    ), 
                )); 
            }catch(Exception $e) { 
                $api_error = $e->getMessage(); 
            } 
             
            if(empty($api_error) && $subscription){ 
				// Retrieve subscription data 
                $subsData = $subscription->jsonSerialize(); 
                // Check whether the subscription activation is successful 
                if($subsData['status'] == 'active'){ 
                    // Subscription info 
                    $planresponse = [];
                    $planresponse = array(
                        'user_id'=>$this->data['user']['userID'],
                        'stripe_subscription_id'=>$subsData['id'],
                        'stripe_customer_id'=>$subsData['customer'],
                        'stripe_plan_id'=>$subsData['plan']['id'],
                        'plan_amount'=>($subsData['plan']['amount']/100),
                        'plan_amount_currency'=>$subsData['plan']['currency'],
                        'plan_interval'=> $subsData['plan']['interval'],
                        'plan_interval_count'=>$subsData['plan']['interval_count'],
                        'payer_email'=>$this->data['user']['email'],
                        'created'=>date("Y-m-d H:i:s", $subsData['created']),
                        'plan_period_start'=>date("Y-m-d H:i:s", $subsData['current_period_start']),
                        'plan_period_end'=>date("Y-m-d H:i:s", $subsData['current_period_end']),
                        'status'=>$subsData['status']
                    );
                    $response = userSubscriptionModel::insert($planresponse);
                    if($response==true){
                        $request->session()->flash('subscription', 'Thank you for Monthly subscription');
                        return back();
                    }
				 } 
			}
			else{ 
				$statusMsg = "Subscription activation failed!"; 
			} 
		}
		else{ 
			$statusMsg = "Subscription creation failed! ".$api_error; 
		} 	
	}
	else{ 
		$statusMsg = "Subscription creation failed! ".$api_error; 
	} 
    }
}

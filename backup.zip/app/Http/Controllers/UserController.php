<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\View;
use Stevebauman\Location\Facades\Location;
use App\Models\AdsModel;
use App\Models\TrailModel;
use App\Models\AdresponseModel;
use App\Models\UserModel;
use App\Models\userSubscriptionModel;
class UserController extends Controller
{
    public function __construct(){
        
        parent::__construct();
        $this->userModel = new UserModel();
    }

   
    public function profile(){
        $user_id=$this->data['user']['userID'];
        $this->data['profile']=UserModel::where('user_id',$user_id)->first();
       
        return view('admin.user.profile',$this->data);
      }
    public function template(Request $request){
        
        if(! $request->isMethod('post')){
            $this->data['tempname'] = 'facebook';
            $this->data['url'] = 'facebook-ad';
            $this->data['adsinfo'] = $this->ads_info->where('ads_category','facebook')->toArray();
            return view('admin.index',$this->data);
        }
         if(!empty($request->search)){
             $search = $request->search;
             if($request->template=='google'){
                 $this->data['adsinfo'] = AdsModel::where('ads_category','google')->where('user_id',$this->data['user']['userID'])->where('company_name', 'LIKE', "%{$search}%")->get()->toArray();
                 $this->data['tempname'] = 'google';
                 $this->data['url'] = 'google-ad';
                  $this->data['page'] =(string)View::make('components/adstemplate',$this->data);
             }
             if($request->template=='facebook'){
                  $this->data['tempname'] = 'facebook';
                  $this->data['url'] = 'facebook-ad';
                  $this->data['adsinfo'] = AdsModel::where('ads_category','facebook')->where('user_id',$this->data['user']['userID'])->where('company_name', 'LIKE', "%{$search}%")->get()->toArray();
                  $this->data['page'] =(string)View::make('components/adstemplate',$this->data);
             }
              if($request->template=='product'){
                  $this->data['tempname'] = 'product';
                  $this->data['url'] = 'Product Description';
                  $this->data['adsinfo'] = AdsModel::where('ads_category','product')->where('user_id',$this->data['user']['userID'])->where('company_name', 'LIKE', "%{$search}%")->get()->toArray();
                  $this->data['page'] =(string)View::make('admin/ads/product/products',$this->data);
             }
              if($request->template=='copy-paste'){
                  $this->data['tempname'] = 'copy-paste';
                  $this->data['url'] = 'copy-paste';
                  $this->data['adsinfo'] = AdsModel::where('ads_category','copy-paste')->where('user_id',$this->data['user']['userID'])->where('company_name', 'LIKE', "%{$search}%")->get()->toArray();
                  $this->data['page'] =(string)View::make('admin/ads/copypaste/copypaste',$this->data);
             }
             if($request->template=='facebook-headline'){
                  $this->data['tempname'] = 'facebook-headline';
                  $this->data['url'] = 'facebook-headline';
                  $this->data['adsinfo'] = AdsModel::where('ads_category','facebook-headline')->where('user_id',$this->data['user']['userID'])->where('company_name', 'LIKE', "%{$search}%")->get()->toArray();
                  $this->data['page'] =(string)View::make('admin/ads/facebook-headline/headline',$this->data);
             }
         }
        if($request->template=='facebook-ads'){
            $this->data['tempname'] = 'facebook';
            $this->data['url'] = 'facebook-ad';
            $this->data['adsinfo'] = $this->ads_info->where('ads_category','facebook')->toArray();
            $this->data['page'] =(string)View::make('components/adstemplate',$this->data);

        }
        if($request->template=='google-ads'){
            $this->data['adsinfo'] =  $this->ads_info->where('ads_category','google')->toArray();
            $this->data['tempname'] = 'google';
            $this->data['url'] = 'google-ad';
            $this->data['page'] =(string)View::make('components/adstemplate',$this->data);

        }
         if($request->template=='product-ads'){
            $this->data['adsinfo'] =  $this->ads_info->where('ads_category','product')->toArray();
            $this->data['tempname'] = 'google';
            $this->data['url'] = 'google-ad';
            $this->data['page'] =(string)View::make('admin/ads/product/products',$this->data);

        }
         if($request->template=='copy-paste'){
            $this->data['adsinfo'] =  $this->ads_info->where('ads_category','copy-paste')->toArray();
            $this->data['tempname'] = 'copy-paste';
            $this->data['url'] = 'copy-paste-ad';
            $this->data['page'] =(string)View::make('admin/ads/copypaste/copypaste',$this->data);

        }
        if($request->template=='facebook-headline'){
            $this->data['adsinfo'] =  $this->ads_info->where('ads_category','facebook-headline')->toArray();
            $this->data['tempname'] = 'facebook-headline';
            $this->data['url'] = 'facebook-headline';
          
            $this->data['page'] =(string)View::make('admin/ads/facebook-headline/headline',$this->data);

        }
      
        $this->data['response'] = true;
        return response()->json($this->data);
        
    }

  
    public function google_ad(Request $request ,$title = '',$id=''){
        
        if(! $request->isMethod('post')){
            if(!empty($title)){

                $this->data['ad_info'] = $this->ads_info->where('company_name',$title)->where('id',decrypt($id))->first();
                $this->data['ads'] =  AdresponseModel::where('ads_id',$this->data['ad_info']['id'])->get()->toArray();
                if(!empty($this->data['ad_info'])){

                    return view('admin.ads.google.update',$this->data);
                }
                else
                return back();

            }
            $this->data['category'] = 'google';
            return view('admin.ads.google.google_ads',$this->data);

        } 
        
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => decrypt($input['category'])
            );
             $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }
                        
           $response =  AdsModel::insertGetId($formData);
           $input['CompanyDescription']="Write a creative ad for the following product to run on Google:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Google:\n-----------\n";
           $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                     'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $Adresponse =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/google_ad',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);
    }

    public function facebook_ad(Request $request , $title='',$id=''){
        
        if(! $request->isMethod('post')){
            if(!empty($title)){
                $this->data['ad_info'] = $this->ads_info->where('company_name',$title)->where('id',decrypt($id))->where('user_id',$this->data['user']['userID'])->first();
                $this->data['ads'] =  AdresponseModel::where('ads_id',decrypt($id))->get()->toArray();
                if(!empty($this->data['ad_info'])){

                    return view('admin.ads.google.update',$this->data);
                }
                else
                return back();

            }
            $this->data['category'] = 'facebook';
            return view('admin.ads.google.google_ads',$this->data);

        } 
        
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => decrypt($input['category'])
            );
                $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }
                  
           $response =  AdsModel::insertGetId($formData);
         $input['CompanyDescription']="Write a creative ad for the following product to run on Facebook:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Facebook:\n-----------\n";
         $i = 0;
         $choices = [];
         for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
                
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                     'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $Adresponse =  AdresponseModel::insertGetId($apiResponse);

           }
            
        }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/ads',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);
    }
    public function product(Request $request , $title='',$id=''){
         if(! $request->isMethod('post')){
            if(!empty($title)){
                   
                $this->data['ad_info'] = $this->ads_info->where('company_name',$title)->where('id',decrypt($id))->where('user_id',$this->data['user']['userID'])->first();
                
                $this->data['ads'] =  AdresponseModel::where('ads_id',$this->data['ad_info']['id'])->get()->toArray();
                if(!empty($this->data['ad_info'])){

                    return view('admin.ads.product.update',$this->data);
                }
                else
                return back();

            }
            // $this->data['category'] = 'facebook';
            // return view('admin.ads.google.google_ads',$this->data);

        } 
        
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => decrypt($input['category'])
            );
               $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }            
             $response =  AdsModel::insertGetId($formData);
           $input['CompanyDescription']="Write a creative ad for the following product to run on Facebook:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Facebook:\n-----------\n";
           $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                     'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
            $Adresponse =  AdresponseModel::insertGetId($apiResponse);


           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/product-ads',['ads'=>$facebook_ad]);
        }
         return response()->json($this->data);
         return view('admin/ads/product/products',$this->data);
    }
    public function product_description(Request $request){
        
        if(! $request->isMethod('post')){
            return view('admin/ads/product/product-description',$this->data);
        }
        else{
            $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                // 'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => 'product'
            );
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                    if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }            
           $response =  AdsModel::insertGetId($formData);
              $input['CompanyDescription']="Write a creative ad for the following product to run on Facebook:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n  ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Facebook:\n-----------\n";
              $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace(',','',str_replace($input['CompanyDescription'],"",$advalue['text'])),
                    'user_id'=>$this->data['user']['userID']
                );
                $Adresponse =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/product-ads',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);
       
    }
    }
  public function copy_paste(Request $request){
        if(! $request->isMethod('post')){
            return view('admin/ads/copypaste/create',$this->data);
        }
        else{
            $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                // 'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => 'copy-paste'
            );
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                    if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }            
           $response =  AdsModel::insertGetId($formData);
              $input['CompanyDescription']="Content:".$input['CompanyDescription']."\n-----------\nTone of voice:Witty";
              $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace(',','',str_replace($input['CompanyDescription'],"",$advalue['text'])),
                    'user_id'=>$this->data['user']['userID']
                );
                $Adresponse =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/copypaste_ad',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);
       
    }
    }
    public function facebook_headline(Request $request){
         if(! $request->isMethod('post')){
          
            $this->data['category'] = 'facebook';
            return view('admin.ads.facebook-headline.create',$this->data);

        } 
        
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                //'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => 'facebook-headline'
            );
                $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }          
           $response =  AdsModel::insertGetId($formData);
         $input['CompanyDescription']="Write a headline for the following product to run on Facebook:\n-----------\nBrand:".$input['Company']."\nDescription:".$input['CompanyDescription']."\n-----------\nThis is the Headline I wrote for Facebook:\n-----------\n";
          $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                     'ads_id' =>$response,
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $Adresponse =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/facebook-headline',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);
    }
    public function update_facebookAd(Request $request){

        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => decrypt($input['category'])
            );
            $input['ad_id'] = decrypt($input['ad_id']);
           $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                         if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }     
           $response =  AdsModel::where('id',$input['ad_id'])->update($formData);
           AdresponseModel::where('ads_id',$input['ad_id'])->delete();
        //   $input['CompanyDescription'] = 'Brand Name: '.$input['Company'].'\n  User Description: '.$input['CompanyDescription'].'\n  Keywords: '.$input['add_keywords'].' ';
         //$response =  AdsModel::insertGetId($formData);
              $input['CompanyDescription']="Write a creative ad for the following product to run on Facebook:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Facebook:\n-----------\n";
             $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$input['ad_id'],
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $response =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/ads',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);

    }
    public function update_googleAd(Request $request){

        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'avoid_keywords'     =>$input['avoid_keyword'],
                'ads_category' => decrypt($input['category'])
            );
            $input['ad_id'] = decrypt($input['ad_id']);
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                   if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }           
           $response =  AdsModel::where('id',$input['ad_id'])->update($formData);
           AdresponseModel::where('ads_id',$input['ad_id'])->delete();
            $input['CompanyDescription']="Write a creative ad for the following product to run on Google:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Google:\n-----------\n";
             $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$input['ad_id'],
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $response =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/google_ad',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);

    }
     public function update_productAd(Request $request){

        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'ads_category' => decrypt($input['category'])
            );
            $input['ad_id'] = decrypt($input['ad_id']);
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                     
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }         
           $response =  AdsModel::where('id',$input['ad_id'])->update($formData);
           AdresponseModel::where('ads_id',$input['ad_id'])->delete();
            // $input['CompanyDescription'] = 'Brand Name: '.$input['Company'].'\n  User Description: '.$input['CompanyDescription'].'\n  Keywords: '.$input['add_keywords'].' ';
         $input['CompanyDescription']="Write a creative ad for the following product to run on Facebook:\n-----------\n".$input['CompanyDescription']."\n-----------\nThese are my keywords:\n-----------\n ".$input['add_keywords'].".\n-----------\nThis is the ad I wrote for Facebook:\n-----------\n";
           $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$input['ad_id'],
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $response =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/product-ads',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);

    }
     public function update_copypaste_ad(Request $request, $title='',$id=''){
  if(! $request->isMethod('post')){
            if(!empty($title)){
                   
                $this->data['ad_info'] = $this->ads_info->where('company_name',$title)->where('id',decrypt($id))->where('user_id',$this->data['user']['userID'])->first();
                
                $this->data['ads'] =  AdresponseModel::where('ads_id',$this->data['ad_info']['id'])->get()->toArray();
                if(!empty($this->data['ad_info'])){

                    return view('admin.ads.copypaste.update',$this->data);
                }
                else
                return back();

            }
            // $this->data['category'] = 'facebook';
            // return view('admin.ads.google.google_ads',$this->data);

        } 
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'ads_category' => decrypt($input['category'])
            );
            $input['ad_id'] = decrypt($input['ad_id']);
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                     
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }         
           $response =  AdsModel::where('id',$input['ad_id'])->update($formData);
           AdresponseModel::where('ads_id',$input['ad_id'])->delete();
            // $input['CompanyDescription'] = 'Brand Name: '.$input['Company'].'\n  User Description: '.$input['CompanyDescription'].'\n  Keywords: '.$input['add_keywords'].' ';
        $input['CompanyDescription']="Content:".$input['CompanyDescription']."\n-----------\nTone of voice:Witty";
          $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$input['ad_id'],
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $response =  AdresponseModel::insertGetId($apiResponse);

           }
           } 
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/copypaste_ad',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);

    }
public function  update_facebook_headline(Request $request, $title='',$id=''){
  if(! $request->isMethod('post')){
            if(!empty($title)){
                   
                $this->data['ad_info'] = $this->ads_info->where('company_name',$title)->where('id',decrypt($id))->where('user_id',$this->data['user']['userID'])->first();
                
                $this->data['ads'] =  AdresponseModel::where('ads_id',$this->data['ad_info']['id'])->get()->toArray();
                if(!empty($this->data['ad_info'])){

                    return view('admin.ads.facebook-headline.update',$this->data);
                }
                else
                return back();

            }
            // $this->data['category'] = 'facebook';
            // return view('admin.ads.google.google_ads',$this->data);

        } 
        $validator = Validator::make($request->all(), [
            'Company' => 'required|max:50',
            'CompanyDescription' => 'required',
            'add_keywords' => 'required'
        ]);
       
        if ($validator->fails()) {
            $errors = $validator->errors();
            $this->data['Company_error'] =$errors->first('Company');
            $this->data['CompanyDescription_error'] =$errors->first('CompanyDescription');
            $this->data['addkeywords_error'] =$errors->first('add_keywords');
        }
        else{
            $this->data['msg'] = '';
            $input = $request->all();
            $formData = array(
                'company_name'=>$input['Company'],
                'discription'=> $input['CompanyDescription'],
                'add_keywords'=>$input['add_keywords'],
                'user_id'    =>$this->data['user']['userID'],
                'ads_category' => decrypt($input['category'])
            );
            $input['ad_id'] = decrypt($input['ad_id']);
            $subscription_id = userSubscriptionModel::where('user_id',$this->data['user']['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(empty($subscription_id)){
                     
                      if($this->trail_quantity <=0){
                           $this->data['msg']  = 'Please purchase offer to generate Ads';
                            return response()->json($this->data);exit;
                      }
                      else{
                           TrailModel::where('user_id',$this->data['user']['userID'])->update(['trail_quantity'=>$this->trail_quantity-1]);
                      }
                  }         
           $response =  AdsModel::where('id',$input['ad_id'])->update($formData);
           AdresponseModel::where('ads_id',$input['ad_id'])->delete();
            // $input['CompanyDescription'] = 'Brand Name: '.$input['Company'].'\n  User Description: '.$input['CompanyDescription'].'\n  Keywords: '.$input['add_keywords'].' ';
         $input['CompanyDescription']="Write a headline for the following product to run on Facebook:\n-----------\nBrand:".$input['Company']."\nDescription:".$input['CompanyDescription']."\n-----------\nThis is the Headline I wrote for Facebook:\n-----------\n";
          $choices = [];
           for ($i = 0; $i < 10; $i++) {
           $facebook_ad =   $this->getSocialAd($input['CompanyDescription']);
           foreach($facebook_ad['choices'] as $advalue){
               $choices[]['text'] = str_replace($input['CompanyDescription'],"",$advalue['text']);
                $apiResponse = array(
                    'ads_id' =>$input['ad_id'],
                    'title'  =>$input['Company'],
                    'description' =>str_replace($input['CompanyDescription'],"",$advalue['text']),
                    'user_id'=>$this->data['user']['userID']
                );
                $response =  AdresponseModel::insertGetId($apiResponse);

           }
           }
           $facebook_ad['choices'] = $choices;
           $facebook_ad['company_name'] = $input['Company'];
           $this->data['response'] = true;
           $this->data['ads'] =(string)View::make('components/facebook-headline',['ads'=>$facebook_ad]);
        }
        return response()->json($this->data);

    }
   

    public function flushSession(Request $request){
        $request->session()->flush();
        return redirect('/');

    }
    public function update_password(Request $request){

        if(! $request->isMethod('post')){
            return view('admin.user.change_password',$this->data);
        }
        $validator = Validator::make($request->all(), [
            'password' => 'required_with:confirm_password|same:confirm_password|min:8',
            'confirm_password' =>'required',
            // 'checkbox'=>'required'
            ]);
        if ($validator->fails()) {
            return redirect('update-password')->withErrors($validator)->withInput();
        }
        else{
            $input = $request->all();
            $formData = array(
                'password'=>Hash::make($input['password'])
            );
            $response =  $this->userModel->where('user_id',$this->data['user']['userID'])->update($formData);
            if($response==true){
                $request->session()->flush();
                if($this->data['user']['role']=='isAdmin'){
                    return redirect('admin/login')->with('message','password updated successfully please login with new password');

                }
                return redirect('login')->with('message','password updated successfully please login with new password');
            }

        }
    }
    public function remove_ad(Request $request){
        $data = [];
        $data['response'] = false;
        $id = decrypt($request->ad_id);
        AdsModel::where('id',$id)->delete();
        AdresponseModel::where('ads_id',$id)->delete();
        $data['response'] = true;
        return response()->json($data);
        
    }
    public function update_userStatus(Request $request , $user_id='',$status=''){
        $update = array(
            'status' =>decrypt($status)
        );
        $response =  $this->userModel::where('user_id',decrypt($user_id))->update($update);
        if($response==true){
            return back();
        }
    }
     public function login(Request $request){
      
        if(!$request->isMethod('post')){
            return back();
           // return view('admin.user.login',$this->data);
        }
       else{
           
        $data = [];
        $data['response'] = false;
        $validator = Validator::make($request->all(), [
            'email' => 'required|max:50|email',
            'password' => 'required|min:8',
        ]);
        if ($validator->fails()) {
             $errors = $validator->errors();
             $data['email'] =$errors->first('email');
             $data['password'] =$errors->first('password');
        }
        else{
           
            $formData = $request->all();
            unset($formData['_token']);
            $status = $this->userModel->login($formData);
            if($status==false){
                //$request->session()->flash('error', 'Wrong Email Or Password!');
                $data['error'] = 'Wrong Email Or Password!';
               // return redirect('login')->with('error', '')->withInput();
            }
            else{
                //   if($status['role']=='isAdmin'){
                //      $request->session()->put('user', $status);
                //      $data['redirect'] = 'dashboard';
                //     }
                if($status['role']=='user'){
                      $subscription_id = userSubscriptionModel::where('user_id',$status['userID'])->select('stripe_subscription_id')->orderBy('created_at','desc')->first();
                  if(!empty($subscription_id)){
                    $subscription =  $this->checkStrip_subscription($subscription_id['stripe_subscription_id']);
                    if($subscription=='canceled'){
                      userSubscriptionModel::where('stripe_subscription_id',$subscription_id['stripe_subscription_id'])->update(['status'=>$subscription]);
                    }
                  }
                  
                  $request->session()->put('user', $status);
                 $data['redirect'] = 'template';
                  //return redirect('template');
                
                  $data['response'] = true;
                }
                else{
                      $data['error'] = 'Sorry you cannot perform this action !';
                }
            }
        }
      
        return response()->json($data);
     }
   }
  
   public function register(Request $request){

        if(! $request->isMethod('post')){
            return back();
            // return view('admin.user.register',$this->data);
            // exit;
        } 
        $data = [];
        $data['response'] =false; 
        $validator = Validator::make($request->all(), [
            'username' => 'required|max:50',
            'email' => 'required|max:50|unique:user|email',
            'password' => 'required_with:confirm_password|same:confirm_password|min:8',
            'confirm_password' =>'required',
            'checkbox'=>'required'
        ]);
        if ($validator->fails()) {
             $errors = $validator->errors();
             $data['username'] =$errors->first('username');
             $data['email'] =$errors->first('email');
             $data['password'] =$errors->first('password');
             $data['confirm_password'] =$errors->first('confirm_password');
             $data['checkbox'] =$errors->first('checkbox');
        }
        else{
            $input = $request->all();
            $location =  request()->ip();
            $location = str_replace('.',':',$location);
            $location_data = Location::get($location);
            $country_name = $location_data->countryName;
            $formData = array(
                'username'=>$input['username'],
                'email'=> $input['email'],
                'password'=>Hash::make($input['password']),
                'role'    =>'user',
                'ip_address'=>request()->ip(),
                'country_name'=>$country_name
            );
         $response =  $this->userModel->insertGetId($formData);
            if(!empty($response)){
                $trailArray = array(
                    'user_id'=>$response,
                    'trail_quantity'=>10
                );
               $response =  TrailModel::insertGetId($trailArray);
                // $user_id = $response;
                // $user_id = bin2hex(encrypt($user_id));  //send encode id 
                // $url = url('/login'.'/'.$user_id);
                // $message = "You registered an account on Trapsol, <br>
                // before being able to use your account you need to verify that this is your email address by clicking below link: <br>
                // ";
                // $message .= '<a href="'.$url.'" class="button btn btn-primary">Reset your password</a><br>';
                // $message .="Kind Regards, Trapsol :<br>";
                // $this->send_email('',$input['email'],'Email Confirmation',$message);
                if(!empty($response)){
                   $data['response'] = true;
                   $data['msg'] = 'Your Account Created successfully';
                   // return redirect('login')->with('message','Your Account Created successfully');
                }
            }
        }
         return response()->json($data);

    }
    
    public function password_recover(Request $request){
        if(! $request->isMethod('post')){
          return view('admin.user.password_recover');
        }
        else{
            $data = array();
            $data['response'] = false;
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|max:50',
            ]);
            if(! $validator->fails()) {
                $post = ['email'=>$request->input('email')]; //   no comments
                $row = $this->userModel->where($post)->first();// no comments
                if(!empty($row)){
                    $user_id = $row['user_id'];
                    $email = $this->createBase64($request->input('email')); // send encode email
                    $user_id = $this->createBase64($user_id);  //send encode id 
                    $url = url('update_password'.'/'.$user_id.'/'.$email);
                    $message = "You recently requested for reset password of your account in Trapsol<br>click the 
                    button below to reset it :<br> ";
                    $message .= '<a href="'.$url.'" class="button btn btn-primary">Reset your password</a>';
                    $this->send_email('',$request->input('email'),'Email Confirmation',$message);
                    $data['response'] = true;
                    $data['msg'] = ' Please follow that email to reset your password';

                }   
                else{
                    $data['msg'] = ' Email does not exist ';

                }
        }
        else{
                $errors = $validator->errors();
                $data['email_error'] =$errors->first('email');
        }
        $data['csrf_token'] = csrf_token();
        echo json_encode($data);
     }
    }
    public function recoverpassword(Request $request,$id='',$email=''){

        if(! $request->isMethod('post')){
            $id = $this->decodeBase64($id);
            $email = $this->decodeBase64($email);
            $where = array('user_id'=>$id,'email'=>$email);
            $result = $this->userModel->where($where)->first(); // checking email, id in db
            if(empty($result)){                    
            return 	redirect('/');   
            }
            $this->data['id'] = $id;
            return view('admin.user.reset_password',$this->data);
        }
        else{
            $this->data['response'] = false; 
            $validator = Validator::make($request->all(), [
                'password' => 'required|min:8',
            ]);
            if($validator->fails()) {
                $errors = $validator->errors();
                $this->data['password_error'] =$errors->first('password');
            }
            else{
                $user = $request->input('id');
                $password = password_hash($_POST['password'],PASSWORD_DEFAULT);
                $passwrodArray = [];
                $passwrodArray = array(
                    'password'=> $password
                );
                $this->UserModel = new UserModel();
                $response = $this->UserModel->where('user_id',$user)->update($passwrodArray);
                if($response==true){
                    $request->session()->flash('message','Password Updated Sucessfully');
                    $this->data['response'] = true; 
                }
            }
            $this->data['csrf_token'] = csrf_token();
            echo json_encode($this->data);
    
        }
       }
    public function update_profile(Request $request){
        //unique:user,'.$this->data['user']['userID'].'
        if(request()->is('update/company_info')){
            $validator = Validator::make($request->all(), [
                'cmp_name' => 'required|max:50',
                'cmp_description' => 'required|max:500'
            ]);
        }
        else{
            $validator = Validator::make($request->all(), [
                'username' => 'required|max:50',
                'email' => 'required|max:50|email',
                'fname' => 'required|max:50',
                'lname' => 'required|max:50',
            ]);
        }
    
        if ($validator->fails()) {
            return redirect('profile')->withErrors($validator)->withInput();
        }
        else{
            $input = $request->all();
            unset($input['_token']);
            $response =  $this->userModel->where('user_id',$this->data['user']['userID'])->update($input);
            if($response==true){
                if(!empty($input['username'])){
                    return redirect('profile')->with('personalinfo','personal information updated successfully');

                }
                else{
                    return redirect('profile')->with('companyinfo','company information updated successfully');
                }
            }
        }
    }
}
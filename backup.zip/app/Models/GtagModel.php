<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GtagModel extends Model
{
    use HasFactory;
    protected $table = 'g_tag';
    protected $primary_key = 'id';
}

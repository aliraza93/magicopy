<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class userSubscriptionModel extends Model
{
    use HasFactory;
    protected $table = 'user_subscriptions';
    protected $primary_key = 'id';

    public function user()
    {
        // morphByMany
        return $this->morphToMany('App\Models\TrailModel','user_id');
    }
}

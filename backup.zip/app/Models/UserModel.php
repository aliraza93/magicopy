<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserModel extends Model
{
    use HasFactory;
    protected $table = 'user';
    protected $fillable = array('email', 'password', 'role','phone');
    protected $primaryKey = 'user_id';

    public function login($user){

		$password=$user['password'];
        $user=$this->where(['email'=>$user['email']])->get()->toArray();
        
		   if(count($user)>0){
               $user = $user[0];
               $verify = password_verify($password, $user['password']);
		   	if($verify){
                   return ['userID'=> $user['user_id'] ,'role' => $user['role'] ,'email' => $user['email'] , 'username'=> $user['username'], 'isLoggedIn' => true,'status'=>$user['status']];
                   
		   	}else{
		   		return false;
		   	}

		   }
    return false;

    }
    public function trailof()
    {
        return $this->hasone('App\Models\TrailModel','user_id','user_id');
    }
    
}

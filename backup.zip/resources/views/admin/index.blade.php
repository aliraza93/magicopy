@extends('layouts/mainAdmin')
@section('content')
<div>
    <style>
        .cmuvkJ {
            border-radius: 15px;
            box-shadow: 1px 2px 15px -5px #000000b3;
            background: white;
            margin: 20px;
            display: inline-block;
            position: relative;
            cursor: pointer;
            width: 248px;
            height: 176px;
        }
        .esbyIi {
            position: absolute;
            left: 50%;
            display: inline-block;
            top: 36%;
            transform: translate(-50%, -50%);
            color: black;
            text-align: center;
            width: 100%;
            padding: 15px;
        }
        .esbyIi >p{
            text-align: left;
            margin-left: 9px;
            color: black;
        }
    </style>
    <h4 style="margin: 21px 0px 0px 28px;"><b>Browse</b></h4>
        <a href="{{url('facebook-ad')}}">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi">
                    <h4 style="text-align: left; font-weight: 600; margin-left: 9px;"><i class="fab fa-facebook-f" aria-hidden="true"></i>&nbsp; New Facebook Ad </h4>
                    <p>A limitless supply of orignal Facebook Ad Copy </p>

                </div>
            </div>
       </a>
       <a href="{{url('google-ad')}}">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi">
                    <h4 style="text-align: left; font-weight: 600; margin-left: 9px;"><i class="fab fa-google"></i>&nbsp; New Google Ad </h4>
                    <p >Create Google Ad with exact requirement and layouts</p>
                </div>
            </div>
       </a>
        <a href="{{url('product-description')}}">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi" style="margin-top: 9px;">
                    <h4 style="text-align: left; font-weight: 600; margin-left: 9px;"><i class="fab fa-product-hunt"></i>&nbsp; Product Description </h4>
                    <p >Launching a new product? Let's couple it with a catchy product description.</p>
                </div>
            </div>
       </a>
        
       <a href="{{url('facebook-headline')}}">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi" style="margin-top: 9px;">
                    <h4 style="text-align: left; font-weight: 600; margin-left: 9px;"><i class="fab fa-facebook-f"></i>&nbsp;Facebook Headline </h4>
                    <p >Launching a new headline with a catchy product description.</p>
                </div>
            </div>
       </a>
       <a href="{{url('copypaste')}}">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi" style="margin-top: 9px;">
                    <h4 style="text-align: left; font-weight: 600; margin-left: 9px;"><i class="fas fa-copy"></i>&nbsp;Content Improver</h4>
                    <p >Launching a new product? Let's couple it with a Copy & Paste catchy product description.</p>
                </div>
            </div>
       </a>
   {{-- <a href="{{url('facebook-ad')}}">
      <div class="sc-iWFSnp cmuvkJ">
        <div class="sc-dRPiIx esbyIi">
            <div>New facebook Ad </div>
        </div>
      </div>
   </a> --}}
</div>

@endsection
<div>
    <style>
        .kiNLFp {
            padding: 20px;
            background-color: white;
            border: 1px solid rgb(132, 141, 211);
            width: 100%;
            border-radius: 10px;
            /* margin-top: 20px; */
            margin-bottom: 20px;
        }
        .fNjRST {
            display: flex;
            -moz-box-pack: center;
            justify-content: center;
            -moz-box-align: center;
            align-items: center;
            width: calc(100% + 40px);
            margin-top: 10px;
            margin-left: -20px;
            height: 260px;
            border-top: 1px solid rgb(220, 220, 220);
            border-bottom: 1px solid rgb(220, 220, 220);
        }
        .jOcitS {
            /* position: relative; */
            left: 3rem;
            bottom: 2.25rem;
            font-family: Helvetica, Open Sans;
            line-height: 1.195rem;
        }
        .kxdBff {
            position: relative;
            width: calc(100% + 40px);
            margin-left: -20px;
            padding-left: 18px;
            padding-top: 8px;
            height: 78px;
            border-bottom: 1px solid rgb(220, 220, 220);
            background-color: rgb(240, 242, 245);
            font-family: Helvetica, Open Sans;
            font-size: 1rem;
            color: rgb(101, 103, 107);
        }
 
    </style>
    @foreach($ads['choices'] as $value)
        
    
    <div class="sc-XhUPp kiNLFp">
        <div style="cursor: pointer; position: relative;">
            <div class="companyInfoContainer">
                {{-- <img src="{{asset('assets')}}/admin/images/ads/megamenu-bg.png" alt="Copysmith Logo"
                    style="width: 40px; border-radius: 50%; border: 1px solid rgb(230, 230, 230);"> --}}
                <div class="sc-hkwnrn jOcitS">
                    <div style="color: rgb(8, 8, 8); font-size: 0.9125rem;"><b>{{$ads['company_name']}}</b></div>
                    <div style="color: rgb(101, 103, 107); font-size: 0.85rem;">Sponsored · <img
                            src="https://i.imgur.com/hDk78b9.png" alt="Earth Icon"
                            style="width: 12px; margin-top: -2px;"></div>
                </div>
            </div>
            <div style="margin-top:1.175rem; color: rgb(5, 5, 5);">
                <div id="mainContent" style="font-size: 0.925rem;">{{$value['text']}}.</div>
            </div>
            <!--<div class="sc-bSFVuW fNjRST">-->
            <!--    <img src="{{asset('assets/admin/images/ads/copysmith-workflow-large.e0aa3117.png')}}"-->
            <!--        alt="Paper airplane illustration" style="width: 260px;">-->
            <!--    </div>-->
            <!--<div class="sc-jvfriV kxdBff">-->
            <!--    <div style="font-size: 0.7625rem;">{{$ads['company_name']}}.COM</div>-->
            <!--    <div id="Headline"-->
            <!--        style="color: rgb(5, 5, 5); font-weight: 600; width: 360px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">-->
            <!--        SAVE 50% OFF</div>-->
            <!--    <div id="Link Description" style="font-size: 0.95rem;"><textarea rows="1"-->
            <!--            style="width: 100%; height: 100%; border-color: currentcolor currentcolor black; border-style: none none solid; border-width: medium medium 1px; border-image: none 100% / 1 / 0 stretch; background-color: inherit; color: inherit; position: relative; font-size: 0.925rem;"-->
            <!--            name="linkDescription">Watch Shop online store</textarea></div>-->
            <!--    <div-->
            <!--        style="position: absolute; color: rgb(5, 5, 5); font-size: 0.9rem; font-weight: 600; text-align: center; padding-top: 0.5rem; top: 20px; right: 18px; width: 100px; height: 38px; border-radius: 6px; background: rgb(228, 230, 235) none repeat scroll 0% 0%;">-->
            <!--        Try Now</div>-->
            <!--</div>-->
            <!--<div class="emoticonContainer" style="padding: 0px; margin-bottom: -3.65rem;"><img-->
            <!--        src="https://i.imgur.com/NmvBVCL.png" alt="Like, Love, Wow Emoticons"-->
            <!--        style="position: relative; top: -1.375rem; left: -4.875rem; transform: scale(0.31); padding: 0px; margin: 0px;"><span-->
            <!--        style="position: relative; top: -1.275rem; left: -9.2rem; font-size: 0.975rem; color: grey;">36</span>-->
            <!--</div>-->
        </div>
        <!--<hr style="width: calc(100% + 8px); margin-left: -4px;">-->
        <!--<div class="row"-->
        <!--    style="position: relative; justify-content: center; align-items: center; z-index: 2; margin-top: -2.125rem; margin-bottom: -0.25rem;">-->
        <!--    <div-->
        <!--        style="margin-top: 1.5rem; color: rgb(105, 105, 105); font-size: 0.8rem; flex: 1 1 0%; margin-left: 1rem;">-->
        <!--        <i>Primary Text: <span class="sc-jifIRw hZmcYU">87 / 125</span> <br>Headline: <span-->
        <!--                class="sc-jifIRw hZmcYU">12 / 40</span> <br>Link description: <span class="sc-jifIRw hZmcYU">23-->
        <!--                / 30</span></i></div>-->
        <!--    <div title="Save Edits" style="margin-top: 1.625rem;" class="sc-tYoTV dtuBJV">Save Edits</div>-->
        <!--    <div style="text-align: right; flex: 1 1 0%; margin-right: 1rem; margin-top: 1.5rem;">-->
        <!--        <i class="fa fa-heart"></i>-->
        <!--        <i class="fa fa-trash"></i>-->
        <!--    </div>-->
        <!--</div>-->
    </div>
    @endforeach
</div>


    <!-- ========== Left Sidebar Start ========== -->
    <div class="left-side-menu">

        <div class="h-100" data-simplebar>

            <!-- User box -->
            

            <!--- Sidemenu -->
            <div id="sidebar-menu">

                <ul id="side-menu">

                  @if(empty($user['subscriber']))
                    <li style=""><a href="javascript:void(0)"> <span style="font-size:17px;border-radius: 44px;" class="text-center btn btn-danger"><span style="font-size:20px" class="trail-quantity">{{$adscounter}}</span> <span >&nbsp;credits left</span></span></a></li>
                    @endif
        
                    <li>
                        <a href="{{url('template')}}">
                            <i class="fab fa-dashcube"></i>
                            <span>Dashboard</span> </a>
                       
                    </li>
                   
                    <li>
                        <a href="#sidebarBaseui" data-toggle="collapse">
                            <i data-feather="pocket"></i>
                            <span> Generate</span>
                            <!--<span class="menu-arrow"></span>-->
                        </a>
                        <div class="collapse" id="sidebarBaseui">
                            <ul class="nav-second-level">
                                <li><a href="javascript:void(0)" onclick="pageload('facebook-ads')"> <i class="fab fa-facebook" style="color: #3737aa;"></i> <span>Facebook Ad</span> </a></li>
                                   <li><a href="javascript:void(0)" onclick="pageload('facebook-headline')"> <i class="fab fa-facebook" style="color: #3737aa;"></i> <span>Facebook Headline</span> </a></li>
                                <li><a href="javascript:void(0)" onclick="pageload('google-ads')"><i class="fab fa-google" style="color: #ff8227;"></i><span> Google Ad</span> </a></li>
                                 <li><a href="javascript:void(0)"  onclick="pageload('product-ads')"><i class="fab fa-product-hunt" style="color: #ff8227;"></i><span> Product Description</span> </a></li>
                                 <li><a href="javascript:void(0)"  onclick="pageload('copy-paste')"><i class="fas fa-copy" style="color: #fe5c5a;"></i><span> Content Improver</span> </a></li>
                               
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="#sidebarTables" data-toggle="collapse">
                            <i data-feather="settings"></i>
                            <span> Tools</span>
                            <!--<span class="menu-arrow"></span>-->
                        </a>
                        <div class="collapse" id="sidebarTables">
                            <ul class="nav-second-level">
                                <li>
                                    <a href="{{url('template')}}" >
                                       <i class="fa fa-th" aria-hidden="true"></i>
                                        <span> Browse </span>
                                      
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                  
                    
                    </ul>

            </div>
            <!-- End Sidebar -->

            <div class="clearfix"></div>

        </div>
        <!-- Sidebar -left -->
        <script type="text/javascript">

            function pageload(page){
                $url = "{{url('/template')}}";
                token = $('input[name="_token"]').val();
                window.history.pushState("template", "Title", "{{url('template')}}");
                $.ajax({
                  url: $url,
                  type: "POST",
                  dataType: 'json',
                  data: {_token: token,template:page},
                  success: function (data) {
                    if(data.response){
                        $('.list').find( 'li.active' ).removeClass( 'active' );
                        $('#'+data.pagename+'').addClass( 'active' );
                        $('.templatediv').html(data.page);
                    }
                    else{
                        alert('Something Went Wrong');
                    }
                  }
                });
            };
            
            </script>
    </div>
    <!-- Left Sidebar End -->


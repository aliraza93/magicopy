
<?php $__env->startSection('content'); ?>

   <!-- Start Banner 
    ============================================= -->
    <div class="banner-area responsive-top-pad inc-shape text-default banner-areahead">
        <div class="container">
            <div class="double-items">
                <div class="row align-center">
                    
                    <?php
                      $main_content_text = json_decode($page_content->main_content);
                    ?>
                    <?php if($main_content_text->main_content_display=='true'): ?>
                    <div class="col-lg-6 info shape">
                        <?php if(!empty($main_content_text->main_content_heading)): ?>
                        <h2 class="wow fadeInDown" data-wow-duration="1s"><?php echo e($main_content_text->main_content_heading); ?></strong></h2>
                        <?php endif; ?>
                        <?php if(!empty($main_content_text->main_content_text)): ?>
                        <p class="wow fadeInLeft" data-wow-duration="1.5s">
                        
                            <?php echo e($main_content_text->main_content_text); ?>

                        </p>
                        <?php endif; ?>
                        <div class="bottom">
                            <a class="btn btn-md btn-gradient wow fadeInDown" data-wow-duration="1.8s" href="#">Get Started</a>
                            <!--<a href="https://www.youtube.com/watch?v=owhuBrGIOsE" class="popup-youtube video-btn wow fadeInUp"><i class="fas fa-play"></i>Watch Video</a>-->
                        </div>
                    </div>
                    <?php endif; ?>
                    <!-- <div class="col-lg-5 offset-lg-1 width-140 thumb wow fadeInRight" data-wow-duration="1s">
                        <img src="<?php echo e(asset('assets')); ?>/frontend/img/illustration/2.png" alt="Thumb">
                    </div> -->
                    <div class="col-lg-5 offset-lg-1 width-140">
                        <div id="carouselExampleIndicators" class="carousel slide carouselhead" data-ride="carousel">
                          <ol class="carousel-indicators" style="left: 40%;">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                          </ol>
                          <div class="carousel-inner">
                            <div class="carousel-item active">
                              <img class="d-block w-100" src="<?php echo e(asset('assets')); ?>/frontend/img/gif/1.gif" alt="First slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="<?php echo e(asset('assets')); ?>/frontend/img/gif/3.gif" alt="Second slide">
                            </div>
                            <div class="carousel-item">
                              <img class="d-block w-100" src="<?php echo e(asset('assets')); ?>/frontend/img/gif/1.gif" alt="Third slide">
                            </div>
                          </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->
    <!-- Start How it Works
    ============================================= -->
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row hiwnumbersrow">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
                        <p class="hiwnumbers">1</p>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-8">
                        <h3 style="font-size: 48px; margin-top: -40px;">Never start from a blank slate again</h3>
                    </div>
                </div>
                <h5>Enter a description and keywords. Instantly generate a dozen variants with accurate mockups.</h5>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="<?php echo e(asset('assets')); ?>/frontend/img/1.jpg" class="img img-responsive">
            </div>
        </div><br><br>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="<?php echo e(asset('assets')); ?>/frontend/img/2.jpg" class="img img-responsive">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row hiwnumbersrow">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
                        <p class="hiwnumbers">2</p>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-8">
                        <h3 style="font-size: 48px; margin-top: -40px;">Launch and manage your campaigns</h3>
                    </div>
                </div>
                <h5>Quickly draft copy for all required channels to launch a new campaign. Edit, like, and share your favourites.</h5>
            </div>            
        </div><br><br>
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row hiwnumbersrow">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
                        <p class="hiwnumbers">3</p>
                    </div>
                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-8">
                        <h3 style="font-size: 48px; margin-top: -40px;">Copywriting that adapts to your tone</h3>
                    </div>
                </div>
                <h5>No more time onboarding yet another freelancer. Copysmith learns from your interactions.</h5>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <img src="<?php echo e(asset('assets')); ?>/frontend/img/3.jpg" class="img img-responsive">
            </div>
        </div><br><br>
    </div>
    <!-- Ends How it Works
    ============================================= -->



    <!-- Start Benefits
    ============================================= -->
    <div id="features" class="our-features-area relative default-padding">
        <!-- Fixed BG -->
        <div class="fixed-bg" style="background-image: url(<?php echo e(asset('assets')); ?>/frontend/img/shape/11.png);"></div>
        <!-- Fixed BG -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2 class="area-title">Our Benefits</h2>
                        <div class="devider"></div>
                        <p>
                            Outlived no dwelling denoting in peculiar as he believed. Behaviour excellent middleton be as it curiosity departure ourselves very extreme future. 
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="feature-items text-center">
                <div class="row">
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="icon">
                               <i class="flaticon-website"></i>
                           </div>
                           <div class="info">
                               <h4>Build Your Campaign</h4>
                               <p>
                                   Passage weather as up am exposed. And natural related man subject. Eagerness get situation his was delighted.
                               </p>
                           </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                           <div class="icon">
                               <i class="flaticon-integration"></i>
                           </div>
                           <div class="info">
                               <h4>World Class Copy</h4>
                               <p>
                                   Passage weather as up am exposed. And natural related man subject. Eagerness get situation his was delighted
                               </p>
                           </div>
                       </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="single-item col-lg-4 col-md-6">
                        <div class="item">
                            <div class="icon">
                               <i class="flaticon-drag"></i>
                           </div>
                           <div class="info">
                               <h4>Instant Results</h4>
                               <p>
                                   Passage weather as up am exposed. And natural related man subject. Eagerness get situation his was delighted.
                               </p>
                           </div>
                        </div>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    
                    <!-- End Single Item -->
                </div>
            </div>

        </div>
    </div>
    <div class="banner-area solid-nav text-capitalized auto-height text-center text-light bg-theme bg-cover" style="background-color: inherit;">
        <div class="container">
            <div class="content-box" style="background-image: url('<?php echo e(asset('assets')); ?>/frontend/img/video-bg.jpg'); margin-bottom: 10px; background-repeat: round;">
                <div class="row align-center">
                    <div class="col-lg-8 offset-lg-2 info">
                        
                        <a class="popup-youtube relative video-play-button" href="https://www.youtube.com/watch?v=owhuBrGIOsE">
                            <i class="fa fa-play"></i>
                        </a>
                    </div>
                    <div class="col-lg-8 offset-lg-2 wow fadeInUp" data-wow-duration="1s">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Shape -->
        
        <!-- End Shape -->
    </div>

    <!-- End Our Benefits -->
        <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonials-area default-padding">

        <!-- Fixed BG -->
        <div class="fixed-bg" style="background-image: url(<?php echo e(asset('assets')); ?>/frontend/img/map.svg);"></div>
        <!-- Fixed BG -->
                        
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2 class="area-title">Customers Review</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="testimonial-items text-center">
                        <div class="carousel slide" data-ride="carousel" id="testimonial-carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <i class="flaticon-left-quotes-sign"></i>
                                    <p>
                                        Instrument or do connection no appearance do invitation. Dried quick round it or order. Add past see west felt did any. Say out noise you taste merry. 
                                    </p>
                                    <span>CEO of Sasoft</span>
                                    <h4>Junl Sarukh</h4>
                                </div>
                                <div class="carousel-item">
                                    <i class="flaticon-left-quotes-sign"></i>
                                    <p>
                                        Instrument or do connection no appearance do invitation. Dried quick round it or order. Add past see west felt did any. Say out noise you taste merry.  
                                    </p>
                                    <span>Director of Sasoft</span>
                                    <h4>Anil Spia</h4>
                                </div>
                                <div class="carousel-item">
                                    <i class="flaticon-left-quotes-sign"></i>
                                    <p>
                                        Instrument or do connection no appearance do invitation. Dried quick round it or order. Add past see west felt did any. Say out noise you taste merry. 
                                    </p>
                                    <span>Developer of Sasoft</span>
                                    <h4>Paul Munni</h4>
                                </div>
                            </div>
                            <!-- End Carousel Content -->

                            <!-- Carousel Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#testimonial-carousel" data-slide-to="0" class="active">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/li.png" alt="Thumb">
                                </li>
                                <li data-target="#testimonial-carousel" data-slide-to="1">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/li.png" alt="Thumb">
                                </li>
                                <li data-target="#testimonial-carousel" data-slide-to="2">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/li.png" alt="Thumb">
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials -->

    <!-- Start Why Choose Us 
    ============================================= -->
    <!--<div class="chooseus-area inc-technology relative left-border bg-gray default-padding-top">
        <div class="container">
            <div class="row">


                <div class="info col-lg-6">
                    <h5>Why choose us</h5>
                    <h2 class="area-title">Create your app page <br> with expert developer</h2>
                    <ul>
                        <li>
                            <h5>First Working Process</h5>
                            <p>
                                Hardly suffer wisdom wishes valley as an. As friendship advantages resolution it alteration stimulated he or increasing. 
                            </p>
                        </li>
                        <li>
                            <h5>Dedicated Team Member</h5>
                            <p>
                                Offered mention greater fifteen one promise because nor. Why denoting speaking fat indulged saw dwelling raillery. 
                            </p>
                        </li>
                        <li>
                            <h5>24/7 Hours Support</h5>
                            <p>
                                Hardly suffer wisdom wishes valley as an. As friendship advantages resolution it alteration stimulated he or increasing. 
                            </p>
                        </li>
                    </ul>
                    <div class="technology">
                        <h4>Technology we use</h4>
                        <div class="icon">
                            <i class="fab fa-java"></i>
                            <i class="fab fa-node-js"></i>
                            <i class="fab fa-php"></i>
                            <i class="fab fa-python"></i>
                            <i class="fab fa-mailchimp"></i>
                        </div>
                    </div>
                </div>


                <div class="thumb width-120 col-lg-6">
                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/illustration/6.png" alt="Thumb">
                </div>

            </div>
        </div>
    </div>-->
    <!-- End Choose us Area -->


    <!-- Start Overview 
    ============================================= -->
    <div id="overview" class="overview-area overflow-hidden default-padding-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2 class="area-title">Quick Software Overview</h2>
                        <div class="devider"></div>
                        <p>
                            Outlived no dwelling denoting in peculiar as he believed. Behaviour excellent middleton be as it curiosity departure ourselves very extreme future. 
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="overview-items">
                <div class="row">
                    <div class="col-lg-4">
                        <ul id="tabs" class="nav nav-tabs">
                            <li class="nav-item">
                                <a href="#" data-target="#tab1" data-toggle="tab" class="active nav-link">Facebook Ads</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-target="#tab2" data-toggle="tab" class="nav-link">Product Descriptions</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-target="#tab3" data-toggle="tab" class="nav-link">Amazon Listings</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" data-target="#tab4" data-toggle="tab" class="nav-link">Amazon Listings</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-8">
                        <div id="tabsContent" class="tab-content wow fadeInUp" data-wow-delay="0.5s">
                            <div id="tab1" class="tab-pane fade active show">
                                <div class="thumb">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/dashboard/1.jpg" alt="Thumb">
                                    <div class="overlay">
                                        
                                    </div>
                                </div>
                            </div>
                            <div id="tab2" class="tab-pane fade">
                                <div class="thumb">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/dashboard/2.jpg" alt="Thumb">
                                </div>
                            </div>
                            <div id="tab3" class="tab-pane fade">
                                <div class="thumb">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/dashboard/3.jpg" alt="Thumb">
                                </div>
                            </div>
                            <div id="tab4" class="tab-pane fade">
                                <div class="thumb">
                                    <img src="<?php echo e(asset('assets')); ?>/frontend/img/dashboard/4.jpg" alt="Thumb">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Overview -->
<!-- Star Faq
    ============================================= -->
    <div class="faq-area default-padding-top">
        <div class="container">
            <div class="faq-items">
                <div class="row align-center">

                    <div class="col-lg-6">
                        <div class="thumb wow fadeInLeft" data-wow-delay="0.5s">
                            <img src="<?php echo e(asset('assets')); ?>/frontend/img/illustration/9.png" alt="Thumb">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="faq-content">
                            <h2 class="area-title">Answer & Question</h2>
                            <div class="accordion" id="accordionExample">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h4 class="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                              Do I need a business plan?
                                        </h4>
                                    </div>

                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>
                                                Continue building numerous of at relation in margaret. Lasted engage roused mother an am at. Other early while if by do to. Missed living excuse as be. Cause heard fat above first time achivement.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                              How long should a business plan be?
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>
                                                Continue building numerous of at relation in margaret. Lasted engage roused mother an am at. Other early while if by do to. Missed living excuse as be. Cause heard fat above first time achivement.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                          Where do I start?
                                      </h4>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>
                                                Continue building numerous of at relation in margaret. Lasted engage roused mother an am at. Other early while if by do to. Missed living excuse as be. Cause heard fat above first time achivement.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End Faq -->


    <!-- Start Pricing Area
    ============================================= -->
    <div id="pricing" class="pricing-area default-padding-top bottom-less">
        <!-- Fixed Shape -->
        
        <!-- End Fixed Shape -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    
                </div>
            </div>
        </div>
        <div class="container">
            <div class="pricing text-center">
                <div class="row">
                    <div class="col-lg-6 col-md-6 single-item">
                       <div class="site-heading light text-center">
                        <h2 class="area-title" style="color: black;">Our Pricing</h2>
                        <div class="devider"></div>
                        <p style="color: black;">
                            Outlived no dwelling denoting in peculiar as he believed. Behaviour excellent middleton be as it curiosity departure ourselves very extreme future. 
                        </p>
                    </div> 
                    </div>
                    <div class="col-lg-6 col-md-6 single-item">
                        
                        <div class="pricing-item" style="text-align: left;">
                            <ul>
                                <li class="pricing-header">
                                    <div>
                            <h4>Growth</h4>
                            <h2><sup>$</sup>49 <sub>/ Mo</sub></h2>
                        </div>  
                                </li>
                                <li><i class="fas fa-check-circle"></i> Every Content Template</li>
                                <li><i class="fas fa-check-circle"></i> Unlimited Content Generation</li>
                                <li><i class="fas fa-check-circle"></i> Same Day Support</li>
                                <li><i class="fas fa-check-circle"></i> Early Access to New Features</li>
                                <div>
                                <li class="footer">
                                    <?php if($isLoggedIn==true && $user['role']=='user'): ?>
                                        <style>
                                            .stripe-button-el:hover{
                                                background-color: transparent;
                                                color: #fe5858 !important;
                                                border: 2px solid #fe5858 !important;
                                            }
                                            .stripe-button-el{
                                               text-align: left;
                                               margin-left:5px;
                                            }
                                        </style>
                                        <form action="<?php echo e(url('subscription')); ?>" method="post" style="text-align: left;margin-left: 6px;">
                                           <?php echo csrf_field(); ?>
                                            <script
                                                src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                                data-key="pk_test_51I17VFLOe2fiPrUVbQMCLYVHd9K1IOPGNqMhdfH72CcT0RCMPIIka2H7iq7eTFToGEjDa2sUfs999uCU2qVbPTqc00UwxXtquQ"
                                                data-amount="4900"
                                                data-name="MagiCopy"
                                                
                                                data-image="<?php echo e(asset('assets/frontend/img/favicon.ico')); ?>"
                                                data-currency="usd"
                                                
                                            >
                                            </script>
                                        </form>
                                    <?php else: ?>
                                      <a class="btn circle btn-theme border btn-sm" id="CheckLogin" href="javascript:void(0)" style="width: 100%;">Get Started</a>
                                    <?php endif; ?>
                                   
                                </li>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Pricing Area -->

    <!-- Start Clients
    ============================================= -->
    <div class="clients-area bg-theme text-light" style="margin: 130px;
    background: #fe5858; padding-top: 16px;">
        <!-- Fixed BG -->
        <div class="fixed-bg" style="background-image: url(<?php echo e(asset('assets')); ?>/frontend/img/shape/10.png);"></div>
        <!-- Fixed BG -->
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-8 info">
                    <h2>Trusted By The World's Best Companies</h2>
                </div>
                
                <div class="col-lg-4">
                    <div class="attr-nav light" style="padding-bottom: 19px;">
                    <ul>
                        <?php if($isLoggedIn==true): ?>
                        
                        <li class="button">
                            <a href="<?php echo e(route('template')); ?>">Get Started - It's Free</a>
                        </li>
                        <?php else: ?>
                        <li class="button">
                            <a href="<?php echo e(route('register')); ?>">Get Started - It's Free</a>
                        </li>
                        
                        <?php endif; ?>
                        
                    </ul>
                </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Clients -->
    
    <script>
        
        $(document).on('click','#CheckLogin',function(e){
            swal({
                    title: "Login?",
                    text: "For subscription please Login!",
                    icon: "warning",
                    button: "OK!",
                    dangerMode: true,
                    }).then((ok) => {
                        if(ok) {
                            window.location.replace('login');
                        }
                    })
              })
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/home/index.blade.php ENDPATH**/ ?>
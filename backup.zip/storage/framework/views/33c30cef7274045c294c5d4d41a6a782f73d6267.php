<!DOCTYPE html>
<html lang="en">
<head>

        <meta charset="utf-8" />
        <title>Magic Copy - Generating Great Content</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/frontend/img/favicon.png">

        <!-- Plugins css -->
        <link href="<?php echo e(asset('assets/admin')); ?>/libs/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/admin')); ?>/libs/selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />
        
        <!-- App css -->
        <link href="<?php echo e(asset('assets/admin')); ?>/css/bootstrap-modern.min.css" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
        <link href="<?php echo e(asset('assets/admin')); ?>/css/app-modern.min.css" rel="stylesheet" type="text/css" id="app-default-stylesheet" />

        <link href="<?php echo e(asset('assets/admin')); ?>/css/bootstrap-modern-dark.min.css" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" />
        <link href="<?php echo e(asset('assets/admin')); ?>/css/app-modern-dark.min.css" rel="stylesheet" type="text/css" id="app-dark-stylesheet" />

        <!-- icons -->
        <link href="<?php echo e(asset('assets/admin')); ?>/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
     <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Tangerine">

        
        <script src="<?php echo e(asset('assets')); ?>/admin/js/jquery.min.js"></script>
        
    </head>

    <body class="loading" data-layout-mode="detached" data-layout='{"mode": "light", "width": "fluid", "menuPosition": "fixed", "sidebar": { "color": "light", "size": "default", "showuser": true}, "topbar": {"color": "dark"}, "showRightSidebarOnPageLoad": true}'>
     <?php echo csrf_field(); ?>
        <!-- Begin page -->
        <div id="wrapper">
    
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin_header','data' => ['user' => $user]]); ?>
<?php $component->withName('admin_header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php if($user['role']=='isAdmin'): ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.supeadmin_sidebar','data' => ['user' => $user]]); ?>
<?php $component->withName('supeadmin_sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php else: ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin_sidebar','data' => ['user' => $user,'adscounter' => $adscounter]]); ?>
<?php $component->withName('admin_sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'adscounter' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adscounter)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php endif; ?>
    <div class="content-page">
        <div class="content" style="margin-bottom: 2%;">
                <!-- Start Content-->
            <div class="container-fluid">
                <div class="templatediv">
                    <?php echo $__env->yieldContent('content'); ?>
               </div>
          </div> 
       </div>
	

<!-- END wrapper -->

<!-- Footer Start -->
<footer class="footer" style="position: absolute;>
    <div class="container-fluid" style="">
        <div class="row">
            <div class="col-md-6">
                <?php echo e(date('Y')); ?>   &copy;<a href="#"> <span style="color:#FE6161"> MagiCopy</span></a>
            </div>
            <div class="col-md-6" style="text-align: right;">
                <span>Developed by: <a href="http://techuire.com/" target="_blank">Techuire</a></span>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->

</div>
</div>



<!-- Right bar overlay-->



<!-- Vendor js -->
<script src="<?php echo e(asset('assets/admin')); ?>/js/vendor.min.js"></script>

<!-- Plugins js-->



<script src="<?php echo e(asset('assets/admin')); ?>/libs/selectize/js/standalone/selectize.min.js"></script>

<!-- Dashboar 1 init js-->
<script src="<?php echo e(asset('assets/admin')); ?>/js/pages/dashboard-1.init.js"></script>

<!-- App js-->
<script src="<?php echo e(asset('assets/admin')); ?>/js/app.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


</body>
</html>
    </html>


<?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/layouts/mainAdmin.blade.php ENDPATH**/ ?>
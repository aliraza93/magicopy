
<?php $__env->startSection('content'); ?>
<style>
    .error{
        color: red;
    }
    .fkyVgZ {
        background-color:#FE6161;
        padding: 10px 40px;
        border: medium none;
        border-radius: 34px;
        box-shadow: rgba(83, 92, 165, 0.2) 0px 1px 2px 2px;
        color: white;
        font-size: 20px;
        margin-top: 30px;
    }

    .jFuWAH {
        height: 100%;
        width: 50vw;
    }

    .edemjN {
        background-color: rgb(242, 242, 242);
    }

</style>
<!-- Start Page Content here -->
<!-- ============================================================== -->

<link href="<?php echo e(asset('assets/admin')); ?>/libs/tagsinput/taginput.css"
rel="stylesheet" type="text/css" id="app-dark-stylesheet" />
<script src="<?php echo e(asset('assets/admin')); ?>/libs/tagsinput/taginput.js"></script>



            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                          
                            
                        </div>
                        <h4 class="page-title"><?php echo e($ad_info['ads_category']=='facebook'?'facebook':'Google'); ?> Ad </h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->



            <div class="row">
                <div class="col-lg-6" style="overflow: auto">
                    <div class="card-box">
                        <h4 class="header-title m-t-0"></h4>

                        <form action="#" id="add_form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12">
                                    <div style="margin-bottom: 20px; margin-top: 20px; width: 100%;">
                                        <div class="CompanyName">
                                            <input type="hidden" name="ad_id" value="<?php echo e(encrypt($ad_info['id'])); ?>">
                                             <input type="hidden" name="category" value="<?php echo e(encrypt($ad_info['ads_category'])); ?>"> 
                                            <div class="form-group">Company Name<span style="color: red;">
                                                    *</span></div>
                                            <input type="text" name="Company"  placeholder="e.g. Candlesmith" class="form-control" value="<?php echo e($ad_info['company_name']); ?>">
                                              
                                            <span class="error" id="Company_error"></span>
                                              
                                        </div>

                                    </div>
                                    <div style="margin-bottom: 20px; margin-top: 20px; width: 100%;">
                                        <div style="position: relative;">
                                            <div>
                                                <div class="form-group">Company or Product Description<span
                                                        style="color: red;"> *</span>
                                                    </div>
                                                    <textarea type="text"
                                                    name="CompanyDescription"
                                                    placeholder="e.g. Candlesmith sells organic, eco-friendly soy-based candles. Our candles are hand-poured in London, UK."
                                                    class="form-control"><?php echo e($ad_info['discription']); ?></textarea>
                                            </div>
                                         
                                              <span class="error" id="CompanyDescription_error"></span>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12" style="position: relative;">
                                    <div style="margin-top: 20px;">
                                        <div style="margin-bottom: 8px; margin-top: 8px; width: 100%;"></div>
                                        <div class="form-group addKeyword-field" id="addKeyword-field-1">
                                            <label for="add_keyword">Add Keywords <span
                                                style="color: red;"> *</span></label>
                                            <input type="text" id="AddKeywordstags" name="add_keywords" value="<?php echo e($ad_info['add_keywords']); ?>" class="form-control" multiple="multiple">
                                           
                                             <span class="error" id="addkeywords_error"></span>
                                           
                                        </div>
                                    </div>
                                    <div style="margin-top: 20px;">
                                        <div style="margin-bottom: 8px; margin-top: 8px; width: 100%;">

                                            <div class="form-group dynamic-field" id="dynamic-field-1">
                                                <label for="avoid_keyword">Keywords to avoid</label>
                                                <input type="text" class="form-control" value="<?php echo e($ad_info['avoid_keywords']); ?>" id="avoid_keyword"
                                                    name="avoid_keyword" placeholder="avoid keywords"
                                                    autocomplete="off">
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="MuiCollapse-container MuiCollapse-hidden" style="min-height: 0px;">
                                    <div class="MuiCollapse-wrapper">
                                        <div class="MuiCollapse-wrapperInner">
                                            <div class="MuiPaper-root MuiAlert-root MuiAlert-standardError MuiPaper-elevation0"
                                                role="alert">
                                                <div class="MuiAlert-message">Please fill in all required elements and
                                                    try
                                                    again. Tip: You need to press 'enter' after entering keywords!</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="width: 100%; text-align: center;">
                                    <h5 class="plz_wait">Please wait</h5>
                                    <?php if($adscounter >0 && empty($user['subscription']['status']) || !empty($user['subscription']['status']) && $user['subscription']['status']=='active'): ?>

                                    <button type="button" id="submit_btn" class="sc-dkIXFM fkyVgZ">Update</button>
                                    <?php else: ?>
                                    <h5 class="text-danger">Please purchase offer to generate Ads</h5>
                                  <?php endif; ?>
                                    
                                    <p style="margin-top: 10px; color: grey; font-size: 12px;">This generation uses
                                        <b>1</b>
                                        credit, and generates 5 - 15 pieces of new content. All content is saved by
                                        default,
                                        so if the first set isn't perfect, try again!<br><br></p>
                                </div>
                        </form>
                    </div> <!-- end card-box -->
                </div>
            </div> <!-- end col-->

            <div class="col-lg-6 sc-bXDlPE sc-ctaXAZ jFuWAH edemjN">
                <style>
                    .kiNLFp {
                        padding: 20px;
                        background-color: white;
                        border: 1px solid rgb(132, 141, 211);
                        width: 100%;
                        border-radius: 10px;
                        /* margin-top: 20px; */
                        margin-bottom: 20px;
                    }
                    .fNjRST {
                        display: flex;
                        -moz-box-pack: center;
                        justify-content: center;
                        -moz-box-align: center;
                        align-items: center;
                        width: calc(100% + 40px);
                        margin-top: 10px;
                        margin-left: -20px;
                        height: 260px;
                        border-top: 1px solid rgb(220, 220, 220);
                        border-bottom: 1px solid rgb(220, 220, 220);
                    }
                    .jOcitS {
                        /* position: relative; */
                        left: 3rem;
                        bottom: 2.25rem;
                        font-family: Helvetica, Open Sans;
                        line-height: 1.195rem;
                    }
                    .kxdBff {
                        position: relative;
                        width: calc(100% + 40px);
                        margin-left: -20px;
                        padding-left: 18px;
                        padding-top: 8px;
                        height: 78px;
                        border-bottom: 1px solid rgb(220, 220, 220);
                        background-color: rgb(240, 242, 245);
                        font-family: Helvetica, Open Sans;
                        font-size: 1rem;
                        color: rgb(101, 103, 107);
                    }
             
                </style>
                <?php if($ad_info['ads_category']=='facebook'): ?>
                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    <div class="sc-XhUPp kiNLFp">
                        <div style="cursor: pointer; position: relative;">
                            <div class="companyInfoContainer">
                                
                                <div class="sc-hkwnrn jOcitS">
                                    <div style="color: rgb(8, 8, 8); font-size: 0.9125rem;"><b><?php echo e($value['title']); ?></b></div>
                                    <div style="color: rgb(101, 103, 107); font-size: 0.85rem;">Sponsored · <img
                                            src="https://i.imgur.com/hDk78b9.png" alt="Earth Icon"
                                            style="width: 12px; margin-top: -2px;"></div>
                                </div>
                            </div>
                            <div style="margin-top:1.175rem; color: rgb(5, 5, 5);">
                                <div id="mainContent" style="font-size: 0.925rem;"><?php echo e($value['description']); ?>.</div>
                            </div>
                            <div class="sc-bSFVuW fNjRST">
                                <img src="<?php echo e(asset('assets/admin/images/template/papery.png')); ?>"
                                    alt="Paper airplane illustration" style="width: 260px;">
                                </div>
                            <div class="sc-jvfriV kxdBff">
                                <div style="font-size: 0.7625rem;"><?php echo e($value['title']); ?>.COM</div>
                                <div id="Headline"
                                    style="color: rgb(5, 5, 5); font-weight: 600; width: 360px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    SAVE 50% OFF</div>
                                <div id="Link Description" style="font-size: 0.95rem;"><textarea rows="1"
                                        style="width: 100%; height: 100%; border-color: currentcolor currentcolor black; border-style: none none solid; border-width: medium medium 1px; border-image: none 100% / 1 / 0 stretch; background-color: inherit; color: inherit; position: relative; font-size: 0.925rem;"
                                        name="linkDescription">Watch Shop online store</textarea></div>
                                <div
                                    style="position: absolute; color: rgb(5, 5, 5); font-size: 0.9rem; font-weight: 600; text-align: center; padding-top: 0.5rem; top: 20px; right: 18px; width: 100px; height: 38px; border-radius: 6px; background: rgb(228, 230, 235) none repeat scroll 0% 0%;">
                                    Try Now</div>
                            </div>
                            <div class="emoticonContainer" style="padding: 0px; margin-bottom: -3.65rem;"><img
                                    src="https://i.imgur.com/NmvBVCL.png" alt="Like, Love, Wow Emoticons"
                                    style="position: relative; top: -1.375rem; left: -4.875rem; transform: scale(0.31); padding: 0px; margin: 0px;"><span
                                    style="position: relative; top: -1.275rem; left: -9.2rem; font-size: 0.975rem; color: grey;">36</span>
                            </div>
                        </div>
                        <hr style="width: calc(100% + 8px); margin-left: -4px;">
                        <div class="row"
                            style="position: relative; justify-content: center; align-items: center; z-index: 2; margin-top: -2.125rem; margin-bottom: -0.25rem;">
                            <div
                                style="margin-top: 1.5rem; color: rgb(105, 105, 105); font-size: 0.8rem; flex: 1 1 0%; margin-left: 1rem;">
                                <i>Primary Text: <span class="sc-jifIRw hZmcYU">87 / 125</span> <br>Headline: <span
                                        class="sc-jifIRw hZmcYU">12 / 40</span> <br>Link description: <span class="sc-jifIRw hZmcYU">23
                                        / 30</span></i></div>
                            <div title="Save Edits" style="margin-top: 1.625rem;" class="sc-tYoTV dtuBJV">Save Edits</div>
                            <div style="text-align: right; flex: 1 1 0%; margin-right: 1rem; margin-top: 1.5rem;">
                                <i class="fa fa-heart"></i>
                                <i class="fa fa-trash"></i>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php if($ad_info['ads_category'] !='facebook'): ?>    
                    <style>
                        .kajamm {
                            background-color: white;
                            width: 100%;
                            padding: 20px;
                            border-radius: 7px;
                            user-select: none;
                            margin-bottom: 20px;
                        }
                        .kypFeC {
                            margin: 0px;
                            font-size: 14px;
                            color: rgb(33, 37, 41);
                        }
                        .gdARiY {
                            color: rgb(28, 27, 168);
                            font-size: 1.125rem;
                        }
                        p {
                            margin-top: 0;
                            margin-bottom: 1rem;
                        }
                    </style>
                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div title="Relaxation Without The Cost" class="sc-citwmv kajamm">
                        <p class="sc-jcVebW kypFeC"><b>Ad</b> • www.<?php echo e($value['title']); ?>.com/ ▾<br>
                        <div class="sc-iBaPrD gdARiY"><?php echo e($value['title']); ?></div>
                        <p><?php echo e($value['description']); ?>...</p>
                        </p>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> <!-- end col -->
        


<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->
<script>
    $('.plz_wait').hide();

$('#AddKeywordstags').tagsInput({
    'unique': true,
});
$('#avoid_keyword').tagsInput({
    'unique': true,
});


$(document).on('click','#submit_btn',function(e){
    $('.error').empty();
    $("#submit_btn").hide();
    $('.plz_wait').fadeIn();
    $url = "<?php echo e($ad_info['ads_category']=='facebook'?url('update/facebook-ad'):url('update/google-ad')); ?>";
    $.ajax({
      url: $url,
      type: "POST",
      dataType: 'json',
      data: $('#add_form').serializeArray(),
      success: function (data) {
        if(data.response==true){
            $('.plz_wait').hide();
           $("#submit_btn").fadeIn();
           $('.edemjN').html(data.ads);
        }
        else{
       
          $('#Company_error').html(data.Company_error);
          $('#CompanyDescription_error').html(data.CompanyDescription_error);
          $('#addkeywords_error').html(data.addkeywords_error);
         
        }
      }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/admin/ads/google/update.blade.php ENDPATH**/ ?>
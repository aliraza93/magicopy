
   <style>
           @media  screen and (min-width: 200px) {
          .topnav-menu >.topbar-dropdown {
            display: block;
          }
        }
   </style>
            <!-- Topbar Start -->
            <div class="navbar-custom" style="background-color: white;">
                <div class="container-fluid">
                    <ul class="list-unstyled topnav-menu float-right mb-0">

                        <li class="dropdown d-none d-lg-inline-block" >
                            <a style="color: #fe5c5a;" class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen" href="#">
                                <i class="fa fa-window-maximize noti-icon"></i>
                            </a>
                        </li>
    
                        
                        <li class="dropdown notification-list topbar-dropdown">
                            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                
                                <span class="pro-user-name ml-1" style="color: #fe5c5a; text-transform: uppercase;">
                                    <?php echo e($user['username']); ?> <i class="fa fa-chevron-down"></i> 
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                <!-- item-->
                                <div class="dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome To Magicopy!</h6>
                                </div>
                                <div class="dropdown-divider"></div>
                                <!-- item-->
                                <a href="<?php echo e(url('/')); ?>" class="dropdown-item notify-item">
                                    <i class="fas fa-home"></i>
                                    <span>Home</span>
                                </a>
                                 
                                 <?php if($user['role']=='user'): ?>
                                    <div class="dropdown-divider"></div>
                                    <a href="<?php echo e(url('profile')); ?>" class="dropdown-item notify-item">
                                        <i class="fas fa-user"></i>
                                        <span>Profile</span>
                                    </a>
                                 <?php endif; ?>
                                <!-- item-->
                                <div class="dropdown-divider"></div>
                                <a href="<?php echo e(url('update-password')); ?>" class="dropdown-item notify-item">
                                    <i class="fa fa-key"></i>
                                    <span>Change Password</span>
                                </a>
                                <div class="dropdown-divider"></div>
    
                                <!-- item-->
                                <a href="<?php echo e(url('logout')); ?>" class="dropdown-item notify-item">
                                    <i class="fa fa-sign-out"></i>
                                    <span>Logout</span>
                                </a>
                                
                            </div>
                        </li>
    
                        
    
                    </ul>
    
                    <!-- LOGO -->
                    <div class="logo-box" style="margin-right: 2%;">
                        <a href="<?php echo e(url('/')); ?>" class="logo logo-dark text-center">
                            <span class="logo-sm" >
                                <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" height="22">
                                <!-- <span class="logo-lg-text-light">UBold</span> -->
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" style="width: 128px;height: 26px;">
                                <!-- <span class="logo-lg-text-light">U</span> -->
                            </span>
                        </a>
    
                        <a href="<?php echo e(url('/')); ?>" class="logo logo-light text-center">
                            <span class="logo-sm ml-2">
                                <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" style="width: 80px;">
                            </span>
                            <span class="logo-lg">
                                <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" style="width: 128px;height: 26px;">
                            </span>
                        </a>
                    </div>
    
                    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                        <li>
                            <button class="button-menu-mobile waves-effect waves-light">
                                <i class="fa fa-bars" style="color: #fe5c5a;"></i>
                            </button>
                        </li>

                        <li>
                            <!-- Mobile menu toggle (Horizontal Layout)-->
                            <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>   
                    </ul>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- end Topbar -->
<?php /**PATH /home/u644618368/domains/usemagicopy.com/public_html/resources/views/components/admin_header.blade.php ENDPATH**/ ?>
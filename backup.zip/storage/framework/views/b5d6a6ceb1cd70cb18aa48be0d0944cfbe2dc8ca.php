
<?php $__env->startSection('content'); ?>
<style>

.error{
    color: red
}

</style>
<div class="account-pages mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <!--col-lg-6 col-xl-5-->
            <div class="col-md-8 ">
                <div class="card bg-pattern">

                    <div class="card-body p-4">
                        
                        <div class="text-center w-75 m-auto">
                            <div class="auth-logo">
                                Change Password
                            <!--    <a href="<?php echo e(url('/')); ?>" class="logo logo-dark text-center">-->
                            <!--        <span class="logo-lg">-->
                            <!--            <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" height="22">-->
                            <!--        </span>-->
                            <!--    </a>-->
            
                            <!--    <a href="<?php echo e(url('/')); ?>" class="logo logo-light text-center">-->
                            <!--        <span class="logo-lg">-->
                            <!--            <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" height="22">-->
                            <!--        </span>-->
                            <!--    </a>-->
                            </div>
                           
                        </div>

                        <form action="<?php echo e(url('update-password')); ?>" method="POST" >
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Enter your password">
                                    <div class="input-group-append" data-password="false">
                                        <div class="input-group-text">
                                            <span class="fa fa-eye font-12"></span>
                                        </div>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"> <?php echo e($message); ?></span>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="password">Confirm Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control" name="confirm_password" value="<?php echo e(old('confirm_password')); ?>" placeholder="Enter your password">
                                    <div class="input-group-append" data-password="false">
                                        <div class="input-group-text">
                                            <span class="fa fa-eye font-12"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" name="checkbox" id="checkbox-signup">
                                    <label class="custom-control-label" for="checkbox-signup">I accept <a href="javascript: void(0);" class="text-dark">Terms and Conditions</a></label>
                                </div>
                                <?php $__errorArgs = ['checkbox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               
                            </div>
                            <div class="form-group mb-0 text-center">
                                <button class="btn btn-success btn-block" style="background-color: #FE6161" type="submit">Update Password</button>
                            </div>

                        </form>

                        

                    </div> <!-- end card-body -->
                </div>
                <!-- end card -->

                <div class="row mt-3">
                    <div class="col-12 text-center">
                        <p class="text-white-50">Already have account?  <a href="<?php echo e(url('login')); ?>" class="text-white ml-1"><b>Sign In</b></a></p>
                    </div> <!-- end col -->
                </div>
                <!-- end row -->

            </div> <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<!-- end page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/user/change_password.blade.php ENDPATH**/ ?>
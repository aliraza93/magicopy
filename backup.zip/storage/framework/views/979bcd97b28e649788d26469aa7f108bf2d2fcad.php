<?php $__env->startSection('content'); ?>
<style>
    .error{
        color: red;
    }
    .fkyVgZ {
        background-color:#FE6161;
        padding: 10px 40px;
        border: medium none;
        border-radius: 34px;
        box-shadow: rgba(83, 92, 165, 0.2) 0px 1px 2px 2px;
        color: white;
        font-size: 20px;
        margin-top: 30px;
    }

    .jFuWAH {
        height: 100%;
        width: 50vw;
    }

    .edemjN {
        background-color: rgb(242, 242, 242);
    }

</style>
<!-- Start Page Content here -->
<!-- ============================================================== -->

<link href="<?php echo e(asset('assets/admin')); ?>/libs/tagsinput/taginput.css"
rel="stylesheet" type="text/css" id="app-dark-stylesheet" />
<script src="<?php echo e(asset('assets/admin')); ?>/libs/tagsinput/taginput.js"></script>



            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                          
                            
                        </div>
                        <h4 class="page-title">Product Description </h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->



            <div class="row">
                <div class="col-lg-6" style="overflow: auto">
                    <div class="card-box">
                        <h4 class="header-title m-t-0"></h4>

                        <form action="#" id="add_form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12">
                                    <div style="margin-bottom: 20px; margin-top: 20px; width: 100%;">
                                        <div class="CompanyName">
                                            <input type="hidden" name="ad_id" value="<?php echo e(encrypt($ad_info['id'])); ?>">
                                             <input type="hidden" name="category" value="<?php echo e(encrypt($ad_info['ads_category'])); ?>"> 
                                            <div class="form-group">Company Name<span style="color: red;">
                                                    *</span></div>
                                            <input type="text" name="Company"  placeholder="e.g. Candlesmith" class="form-control" value="<?php echo e($ad_info['company_name']); ?>">
                                              
                                            <span class="error" id="Company_error"></span>
                                              
                                        </div>

                                    </div>
                                    <div style="margin-bottom: 20px; margin-top: 20px; width: 100%;">
                                        <div style="position: relative;">
                                            <div>
                                                <div class="form-group">Company or Product Description<span
                                                        style="color: red;"> *</span>
                                                    </div>
                                                    <textarea type="text"
                                                    name="CompanyDescription"
                                                    placeholder="e.g. Candlesmith sells organic, eco-friendly soy-based candles. Our candles are hand-poured in London, UK."
                                                    class="form-control"><?php echo e($ad_info['discription']); ?></textarea>
                                            </div>
                                         
                                              <span class="error" id="CompanyDescription_error"></span>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12" style="position: relative;">
                                    <div style="margin-top: 20px;">
                                        <div style="margin-bottom: 8px; margin-top: 8px; width: 100%;"></div>
                                        <div class="form-group addKeyword-field" id="addKeyword-field-1">
                                            <label for="add_keyword">Brand Keywords <span
                                                style="color: red;"> *</span></label>
                                            <input type="text" id="AddKeywordstags" name="add_keywords" value="<?php echo e($ad_info['add_keywords']); ?>" class="form-control" multiple="multiple">
                                           
                                             <span class="error" id="addkeywords_error"></span>
                                           
                                        </div>
                                    </div>
                                </div>
                                <div class="MuiCollapse-container MuiCollapse-hidden" style="min-height: 0px;">
                                    <div class="MuiCollapse-wrapper">
                                        <div class="MuiCollapse-wrapperInner">
                                            <div class="MuiPaper-root MuiAlert-root MuiAlert-standardError MuiPaper-elevation0"
                                                role="alert">
                                                <div class="MuiAlert-message">Please fill in all required elements and
                                                    try
                                                    again. Tip: You need to press 'enter' after entering keywords!</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="width: 100%; text-align: center;">
                                     <h5 class="plz_wait"><img style="width:50%;" src="<?php echo e(asset('assets/admin/loader/please_wait.gif')); ?>"></h5>
                                    <?php if($adscounter >0 && empty($user['subscription']['status']) || !empty($user['subscription']['status']) && $user['subscription']['status']=='active'): ?>

                                    <button type="button" id="submit_btn" class="sc-dkIXFM fkyVgZ">Update</button>
                                    <?php else: ?>
                                    <h5 class="text-danger">Please purchase offer to generate Ads</h5>
                                  <?php endif; ?>
                                  <h5 class="text-danger error_msg"></h5>
                                    
                                    <p style="margin-top: 10px; color: grey; font-size: 12px;">This generation uses
                                        <b>1</b>
                                        credit, and generates 5 - 15 pieces of new content. All content is saved by
                                        default,
                                        so if the first set isn't perfect, try again!<br><br></p>
                                </div>
                        </form>
                    </div> <!-- end card-box -->
                </div>
            </div> <!-- end col-->

            <div class="col-lg-6 sc-bXDlPE sc-ctaXAZ jFuWAH edemjN">
                <style>
                    .kiNLFp {
                        padding: 20px;
                        background-color: white;
                        border: 1px solid rgb(132, 141, 211);
                        width: 100%;
                        border-radius: 10px;
                        /* margin-top: 20px; */
                        margin-bottom: 20px;
                    }
                    .fNjRST {
                        display: flex;
                        -moz-box-pack: center;
                        justify-content: center;
                        -moz-box-align: center;
                        align-items: center;
                        width: calc(100% + 40px);
                        margin-top: 10px;
                        margin-left: -20px;
                        height: 260px;
                        border-top: 1px solid rgb(220, 220, 220);
                        border-bottom: 1px solid rgb(220, 220, 220);
                    }
                    .jOcitS {
                        /* position: relative; */
                        left: 3rem;
                        bottom: 2.25rem;
                        font-family: Helvetica, Open Sans;
                        line-height: 1.195rem;
                    }
                    .kxdBff {
                        position: relative;
                        width: calc(100% + 40px);
                        margin-left: -20px;
                        padding-left: 18px;
                        padding-top: 8px;
                        height: 78px;
                        border-bottom: 1px solid rgb(220, 220, 220);
                        background-color: rgb(240, 242, 245);
                        font-family: Helvetica, Open Sans;
                        font-size: 1rem;
                        color: rgb(101, 103, 107);
                    }
             
                </style>
               
                     <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sc-XhUPp kiNLFp">
                            <div style="cursor: pointer; position: relative;">
                                <div class="companyInfoContainer">
                                    
                                    <div class="sc-hkwnrn jOcitS">
                                        <div style="color: rgb(8, 8, 8); font-size: 0.9125rem;"><b><?php echo e($value['title']); ?></b></div>
                                         <div style="color: rgb(101, 103, 107); font-size: 0.85rem;">Sponsored · <img
                            src="https://i.imgur.com/hDk78b9.png" alt="Earth Icon"
                            style="width: 12px; margin-top: -2px;"></div>
                                    </div>
                                </div>
                                <div style="margin-top:1.175rem; color: rgb(5, 5, 5);">
                                    <div id="mainContent" style="font-size: 0.925rem;"><?php echo e($value['description']); ?>.</div>
                                </div>
                           
                            </div>
                            <!--<hr style="width: calc(100% + 8px); margin-left: -4px;">-->
                          
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
            </div> <!-- end col -->
        


<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->
<script>
    $('.plz_wait').hide();

$('#AddKeywordstags').tagsInput({
    'unique': true,
});
$('#avoid_keyword').tagsInput({
    'unique': true,
});


$(document).on('click','#submit_btn',function(e){
    $('.error').empty();
    $("#submit_btn").hide();
    $('.plz_wait').fadeIn();
    $url = "<?php echo e(url('update/product-ad')); ?>";  
    $.ajax({
      url: $url,
      type: "POST",
      dataType: 'json',
      data: $('#add_form').serializeArray(),
      success: function (data) {
          $('.plz_wait').hide();
          $("#submit_btn").show();
        if(data.response==true){
             $('.trail-quantity').text($('.trail-quantity').text()-1);
             $('.edemjN').html(data.ads);
        }
        else{
              $('.plz_wait').hide();
              $('.error_msg').html(data.msg);
              $("#submit_btn").fadeIn();
              $('#Company_error').html(data.Company_error);
              $('#CompanyDescription_error').html(data.CompanyDescription_error);
              $('#addkeywords_error').html(data.addkeywords_error);
             
        }
      }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/ads/product/update.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Sasoft - Software Landing Page">

    <!-- ========== Page Title ========== -->
    <title>Magic Copy - Generating Great Content</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets')); ?>/frontend/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/themify-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/flaticon-set.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/magnific-popup.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/owl.carousel.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/owl.theme.default.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/animate.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/bootsnav.css" rel="stylesheet" />
    <link href="<?php echo e(asset('assets')); ?>/frontend/style.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets')); ?>/frontend/css/responsive.css" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->
    
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/jquery-1.12.4.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/popper.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/bootstrap.min.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="<?php echo e(asset('assets')); ?>/frontend/js/html5/html5shiv.min.js"></script>
      <script src="<?php echo e(asset('assets')); ?>/frontend/js/html5/respond.min.js"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700;800&amp;display=swap" rel="stylesheet">
    <style type="text/css">
        @media  screen and (max-width: 1024px) {
        .carouselhead{
            width: 400px; 
            height: 400px;
        }
    .banner-area .info.shape {
        margin-top: 110px;
    }
    }
    .carouselhead{
            width: 450px; 
            height: 450px;
        }
        .hiwnumbers{
            font-family: "Open Sans", sans-serif;
        left: -18px;
        position: relative;
        font-style: normal;
        font-weight: bold;
        font-size: 144px;
        line-height: 30px;
        color: #fe5c5a;
        }
        .banner-areahead{
            border-bottom: 1px solid #fe5c5a;
            margin-bottom: 70px;
            box-shadow: 0px -6px 20px #fe5c5a;
        }
        .hiwnumbersrow{
            padding-top: 25%;
        }
    </style>
</head>


<body>

    <!-- Preloader Start -->
   <!-- <div class="se-pre-con"></div> -->
    <!-- Preloader Ends -->
     <?php if (isset($component)) { $__componentOriginal3cecdc575ec71454cc5ccfe3b0373988cc555af3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Userheader::class, ['isLoggedIn' => $isLoggedIn]); ?>
<?php $component->withName('userheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3cecdc575ec71454cc5ccfe3b0373988cc555af3)): ?>
<?php $component = $__componentOriginal3cecdc575ec71454cc5ccfe3b0373988cc555af3; ?>
<?php unset($__componentOriginal3cecdc575ec71454cc5ccfe3b0373988cc555af3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <?php echo $__env->yieldContent('content'); ?>
     <?php if (isset($component)) { $__componentOriginal20711de9af961cbd9672d4c93c239b250a54a17a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Userfooter::class, []); ?>
<?php $component->withName('userfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal20711de9af961cbd9672d4c93c239b250a54a17a)): ?>
<?php $component = $__componentOriginal20711de9af961cbd9672d4c93c239b250a54a17a; ?>
<?php unset($__componentOriginal20711de9af961cbd9672d4c93c239b250a54a17a); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <!-- jQuery Frameworks
    ============================================= -->
  
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/jquery.appear.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/jquery.easing.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/modernizr.custom.13711.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/wow.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/progress-bar.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/isotope.pkgd.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/count-to.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/YTPlayer.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/bootsnav.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/frontend/js/main.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   <?php if(!empty(session('subscription'))): ?>
        <script>
            swal({
                title: "Congratulation",
                text: "<?php echo e(session('subscription')); ?>",
                icon: "success",
                buttons: true,
                dangerMode: true,
            })
        </script>
   
   <?php endif; ?>
</body>
</html><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/layouts/mainuser.blade.php ENDPATH**/ ?>
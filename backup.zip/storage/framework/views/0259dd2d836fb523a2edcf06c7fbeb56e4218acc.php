
<?php $__env->startSection('content'); ?>
<style>
    /*.col-6,.col-4 {*/
    /*    border: 1px solid;*/
    /*}*/
    .remove-gif {
        position: absolute;
        color: #F35D5D;
        margin-top: -8px;
        margin-left: -7px;
        }
        .fa-times {
        font-size: 20px;
        }
</style>
<div class="row" style="margin-top:3%">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if(!empty(session('message'))): ?>
                  <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>
                
                    <?php echo csrf_field(); ?>
                    <h1 style="text-align:center;margin-right: 69px;color: #fe5c5a;">Magic Copy</h1>
                <div class="row">
                    <div class="col-6">
                        <form action="<?php echo e(url('manage-page')); ?>" method="post" id="main_content" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Main Content</h5>
                            <div class="form-group">
                                <?php
                                  $main_content_text = json_decode($page_content->main_content);
                                ?>
                               
                                <div class="form-group">
                                      <label for=""></label>
                                      <select class="form-control" name="main_content_display" id="">
                                        <option value="true" <?php echo e($main_content_text->main_content_display=='true'?'selected=selected':''); ?>>Active</option>
                                        <option value="false" <?php echo e($main_content_text->main_content_display=='false'?'selected=selected':''); ?>>In Active</option>
                                      </select>
                                </div>
                                
                            </div>
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e($main_content_text->main_content_heading); ?>" name="main_content_heading"/>
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="main_content_text"  cols="30" rows="5"><?php echo e($main_content_text->main_content_text); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="my-input">Upload Gif</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file[]" multiple >
                            </div>
                            <div class="row mb-4">
                                <?php if(!empty($main_content_text->file)): ?>
                                 <?php $__currentLoopData = $main_content_text->file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <input type="hidden" name="image[]" value="<?php echo e($value); ?>">
                                 <div class="col-2 ml-4 ">
                                     <a href="remove-gif/<?php echo e($key); ?>" class="remove-gif"><i class="fa fa-times"></i></a>
                                    <img style="width:113px;height:84px" src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($value); ?>" alt="no image">
                                 </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" id="main-submit-button" class="btn btn-success">Update</button>
                            </div>
                        </form>
                        
                    </div>
                    <div class="col-6">
                        <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content-1" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Content 1</h5>
                                <?php
                                $content1 = json_decode($page_content->content1);
                                ?>
                              
                                 <div class="form-group">
                                      <label for=""></label>
                                      <select class="form-control" name="content1_display" id="">
                                        <option value="true" <?php echo e($content1->content1_display=='true'?'selected=selected':''); ?>>Active</option>
                                        <option value="false" <?php echo e($content1->content1_display=='false'?'selected=selected':''); ?>>In Active</option>
                                      </select>
                                </div>
                           
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content1->content1_heading)?$content1->content1_heading:''); ?>" name="content1_heading"/>
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content1_text"  cols="30" rows="5"><?php echo e(!empty($content1->content1_text)?$content1->content1_text:''); ?></textarea>
                            </div>
                            <input type="hidden" name="image" value="<?php echo e(!empty($content1->file)?$content1->file:''); ?>">
                            <div class="form-group">
                                <label for="my-input">Upload Image</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file" >
                            </div>
                            <div class="row mb-4">
                                <?php if(!empty($content1->file)): ?>
                                 <div class="col-2 ml-4 ">
                                    <img style="width:113px;height:84px"  src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($content1->file); ?>" alt="no image">
                                 </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-success" id="content1_submit">Update</button>
                            </div>
                        </form>
                    </div>
                     </div>
        </div>
        </div>
         <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content-2" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Content 2</h5>
                           
                                <?php
                                $content2 = json_decode($page_content->content2);
                                ?>
                               
                                <div class="form-group">
                                      <label for=""></label>
                                      <select class="form-control" name="content2_display" id="">
                                        <option value="true" <?php echo e($content2->content2_display=='true'?'selected=selected':''); ?>>Active</option>
                                        <option value="false" <?php echo e($content2->content2_display=='false'?'selected=selected':''); ?>>In Active</option>
                                      </select>
                                </div>
                            
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" name="content2_heading" type="text" value="<?php echo e(!empty($content2->content2_heading)?$content2->content2_heading:''); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content2_text"  cols="30" rows="5"><?php echo e(!empty($content2->content2_text)?$content2->content2_text:''); ?></textarea>
                            </div>
                            <input type="hidden" name="image" value="<?php echo e(!empty($content2->file)?$content2->file:''); ?>">
                            <div class="form-group">
                                <label for="my-input">Upload Image</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file" >
                            </div>
                            <div class="row mb-4">
                                <?php if(!empty($content2->file)): ?>
                                 <div class="col-2 ml-4 ">
                                     <img style="width:113px;height:84px"  src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($content2->file); ?>" alt="no image">
                                 </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-success" id="content2_submit">Update</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-6">
                        <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content3" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Content 3</h5>
                            
                                <?php
                                $content3 = json_decode($page_content->content3);
                                ?>
                                  <div class="form-group">
                                      <label for=""></label>
                                      <select class="form-control" name="content3_display" id="">
                                        <option value="true" <?php echo e($content3->content3_display=='true'?'selected=selected':''); ?>>Active</option>
                                        <option value="false" <?php echo e($content3->content3_display=='false'?'selected=selected':''); ?>>In Active</option>
                                      </select>
                                </div>
                          
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" name="content3_heading" type="text" value="<?php echo e(!empty($content3->content3_heading)?$content3->content3_heading:''); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content3_text"  cols="30" rows="5"><?php echo e(!empty($content3->content3_text)?$content3->content3_text:''); ?></textarea>
                            </div>
                            <input type="hidden" name="image" value="<?php echo e(!empty($content3->file)?$content3->file:''); ?>">
                            <div class="form-group">
                                <label for="my-input">Upload Image</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file" >
                            </div>
                            <div class="row mb-4">
                                <?php if(!empty($content3->file)): ?>
                                 <div class="col-2 ml-4 ">
                                    <img style="width:113px;height:84px"  src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($content3->file); ?>" alt="no image">
                                 </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-success" id="content3_submit">Update</button>
                            </div>
                        </form>
                       
                    </div>
                    
                    
                </div>
                  </div>
                    </div>
                <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content_4" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="card">
                     <div class="card-body">
                <div class="row">
                    
                            <div class="col-12" >
                                <h5>Content 4 (Our Benefits)</h5>
                               
                                    <?php
                                    $content4 = json_decode($page_content->content4);
                                    ?>
                                   
                                    <div class="form-group">
                                          <label for=""></label>
                                          <select class="form-control" name="content4_display" id="">
                                            <option value="true" <?php echo e($content4->content4_display=='true'?'selected=selected':''); ?>>Active</option>
                                            <option value="false" <?php echo e($content4->content4_display=='false'?'selected=selected':''); ?>>In Active</option>
                                          </select>
                                    </div>
                               
                                <div class="form-group">
                                    <label for="my-input">Heading</label>
                                    <input id="my-input" class="form-control" name="content4_heading" type="text" value="<?php echo e(!empty($content4->content4_heading)?$content4->content4_heading:''); ?>" />
                                </div>
                                <div class="form-group">
                                    <label for="my-input">text</label>
                                    <textarea id="my-input" class="form-control" type="text" name="content4_text"  cols="30" rows="5"><?php echo e(!empty($content4->content4_text)?$content4->content4_text:''); ?></textarea>
                                </div>
                            </div>
                                
                            <div class="col-4">
                                <h5>Section 1</h5>
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" name="content4_section1_heading" type="text" value="<?php echo e(!empty($content4->content4_section1_heading)?$content4->content4_section1_heading:''); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content4_section1_text"  cols="30" rows="5"><?php echo e(!empty($content4->content4_section1_text)?$content4->content4_section1_text:''); ?></textarea>
                            </div>
                            </div>
                            <div class="col-4">
                                <h5>Section 2</h5>
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" name="content4_section2_heading" type="text" value="<?php echo e(!empty($content4->content4_section2_heading)?$content4->content4_section2_heading:''); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content4_section2_text"  cols="30" rows="5"><?php echo e(!empty($content4->content4_section2_text)?$content4->content4_section2_text:''); ?></textarea>
                            </div>
                            </div>
                            <div class="col-4">
                                <h5>Section 3</h5>
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" name="content4_section3_heading" type="text" value="<?php echo e(!empty($content4->content4_section3_heading)?$content4->content4_section3_heading:''); ?>" />
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content4_section3_text"  cols="30" rows="5"><?php echo e(!empty($content4->content4_section3_text)?$content4->content4_section3_text:''); ?></textarea>
                            </div>
                            </div>
                            <div class="col-12 mt-2">
                                <div class="form-group text-center">
                                    <button type="button" class="btn btn-success" id="content4_submit">Update</button>
                                </div>
                            </div>
                        
                </div>
                </div>
               </div>
            </form>
            <div class="card">
                <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content5" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Content 5 (Quick Software Overview)</h5>
                                <?php
                                   $content5 = json_decode($page_content->content5);
                                ?>
                                
                                <div class="form-group">
                                          <label for=""></label>
                                          <select class="form-control" name="content5_display" id="">
                                            <option value="true" <?php echo e($content5->content5_display=='true'?'selected=selected':''); ?>>Active</option>
                                            <option value="false" <?php echo e($content5->content5_display=='false'?'selected=selected':''); ?>>In Active</option>
                                          </select>
                                </div>
                           
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content5->content5_heading)?$content5->content5_heading:''); ?>" name="content5_heading"/>
                            </div>
                            <div class="form-group">
                                <label for="my-input">text</label>
                                <textarea id="my-input" class="form-control" type="text" name="content5_text"  cols="30" rows="5"><?php echo e(!empty($content5->content5_text)?$content5->content5_text:''); ?></textarea>
                            </div>
                            
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-primary" id="content5-submit">Update</button>
                            </div>
                        </form>
                        
                          <form action="" method="post" id="content7" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <h5>Content 7 (Pricing)</h5>
                               
                                    <?php
                                    $content7 = json_decode($page_content->content7);
                                    ?>
                                   
                                    <div class="form-group">
                                          <label for=""></label>
                                          <select class="form-control" name="content7_display" id="">
                                            <option value="true" <?php echo e($content7->content7_display=='true'?'selected=selected':''); ?>>Active</option>
                                            <option value="false" <?php echo e($content7->content7_display=='false'?'selected=selected':''); ?>>In Active</option>
                                         </select>
                                    </div>
                                    
                               
                                <div class="form-group">
                                    <label for="my-input">Heading</label>
                                    <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content7->content7_heading)?$content7->content7_heading:''); ?>" name="content7_heading"/>
                                </div>
                                <div class="form-group">
                                    <label for="my-input">text</label>
                                    <textarea id="my-input" class="form-control" type="text" name="content7_text"  cols="30" rows="5"><?php echo e(!empty($content7->content7_text)?$content7->content7_text:''); ?></textarea>
                                </div>
                                <div class="form-group text-center">
                                    <button type="button" class="btn btn-success" id="content7_submit">Update</button>
                                </div>
                          </form>
                        
                    </div>
                    <div class="col-6">
                        <form action="" method="post" id="content6" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h5>Content 6 </h5>
                                <?php
                                   $content6 = json_decode($page_content->content6);
                                ?>
                               
                                   <div class="form-group">
                                          <label for=""></label>
                                          <select class="form-control" name="content6_display" id="">
                                            <option value="true" <?php echo e($content6->content6_display=='true'?'selected=selected':''); ?>>Active</option>
                                            <option value="false" <?php echo e($content6->content6_display=='false'?'selected=selected':''); ?>>In Active</option>
                                         </select>
                                    </div>
                            
                            <div class="form-group">
                                <label for="my-input">Heading</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content6->content6_heading)?$content6->content6_heading:''); ?>" name="content6_heading"/>
                            </div>
                            <div class="form-group">
                                <label for="my-input">Question 1</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content6->content6_question1)?$content6->content6_question1:''); ?>" name="content6_question1"/>
                                <label for="my-input">Answer</label>
                                <textarea id="my-input" class="form-control" type="text" cols="30" rows="2" name="content6_answer1"><?php echo e(!empty($content6->content6_answer1)?$content6->content6_answer1:''); ?> </textarea>
                           
                            </div>
                            <div class="form-group">
                                <label for="my-input">Question 2</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content6->content6_question2)?$content6->content6_question2:''); ?>" name="content6_question2"/>
                                <label for="my-input">Answer</label>
                                <textarea id="my-input" class="form-control" type="text"  cols="30" rows="2" name="content6_answer2"> <?php echo e(!empty($content6->content6_answer2)?$content6->content6_answer2:''); ?></textarea>
                           
                            </div>
                            <div class="form-group">
                                <label for="my-input">Question 3</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content6->content6_question3)?$content6->content6_question3:''); ?>" name="content6_question3"/>
                                <label for="my-input">Answer</label>
                                <textarea id="my-input" class="form-control" type="text" cols="30" rows="2"  name="content6_answer3"><?php echo e(!empty($content6->content6_answer3)?$content6->content6_answer3:''); ?> </textarea>
                           
                            </div>
                            <div class="form-group text-center">
                                <button type="button" class="btn btn-success" id="content6-submit">Update</button>
                            </div>
                        </form>
                     </div>
                     
                </div>
                 </div>
                  </div>
                <form action="<?php echo e(url('manage-page')); ?>" method="post" id="content_8">
                    <?php echo csrf_field(); ?>
                 <div class="card">
                <div class="card-body">
                    <div class="row">
                      
                        <?php
                          $content8 = json_decode($page_content->content8);
                        ?>
                        <div class="col-8">
                            <h5>Content 8 </h5>
                            <div class="form-group">
                                <label for="my-input">Video Url</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e(!empty($content8->content8_vedio_url)?$content8->content8_vedio_url:''); ?>" name="content8_vedio_url"/>
                            </div>
                            
                            <iframe width="420" height="315" src="https://www.youtube.com/embed/owhuBrGIOsE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            <input type="checkbox" hidden checked value="true" name="content8_display" />
                            <input type="hidden" name="image" value="<?php echo e(!empty($content8->file)?$content8->file:''); ?>">
                            <div class="form-group">
                                <label for="my-input">Upload Image</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file" >
                            </div>
                            <div class="row mb-4">
                                <?php if(!empty($content8->file)): ?>
                                 <div class="col-2 ml-4 ">
                                    <img style="width:113px;height:84px"  src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($content8->file); ?>" alt="no image">
                                 </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn btn-success" id="content8-submit">Update</button>
                            </div>
                        </div>
                    </div>
                   </div>
                     </div>
                </form>
               
                
           
    </div>
</div>
<script src="<?php echo e(asset('assets/admin/js/user-dashboard/manage_page.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/admin/manage_page.blade.php ENDPATH**/ ?>
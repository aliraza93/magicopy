
<?php $__env->startSection('content'); ?>
<style>
    .col-6,.col-4 {
        border: 1px solid;
    }
</style>
<div class="row" style="width: 50%;margin: auto;">
    <div class="col-12">
        <div class="card" style="margin-top: 30px;">
            <div class="card-body">
                <h2 style="text-align:center;margin-right: 69px;color: #fe5c5a;">Pakage Pricing</h2>

                    <form action="pricing" method="post">
                        <?php echo csrf_field(); ?>
                    <div class="col-12">
                       
                        <div class="form-group">
                              <label for="">Duration</label>
                              <select class="form-control" name="duration" id="duration">
                                <option value="month" <?php echo e($pakage->duration=='year'?'selected=selected':''); ?>>month</option>
                                 <option value="year" <?php echo e($pakage->duration=='year'?'selected=selected':''); ?>>year</option>
                                
                              </select>
                            <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                          <div class="form-group">
                            <label for="my-input">Discount (%)</label>
                            <input  class="form-control" value="<?php echo e(!empty($pakage->discount)?$pakage->discount:''); ?>" max="99" type="number" id="discount" name="discount">
                           
                        </div>
                        <div class="form-group">
                            <label for="my-input">Price</label>
                            <input id="pricing" class="form-control" value="<?php echo e(!empty($pakage->price)?$pakage->price:''); ?>" type="text" name="price">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-danger"><?php echo e($message); ?></span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                       
                         <div class="form-group" style="text-align: center;margin-top: 24px;">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </form>
               
            </div>
        </div>
    </div>
</div>

<script>

    
    data_fetch();
    function data_fetch(){
         duration = $('#duration').val();
          $.ajax({
          url: 'fetch_price',
          type: "POST",
          dataType: 'json',
          data: {'duration':duration,
              "_token": "<?php echo e(csrf_token()); ?>",
          },
          success: function (data) {
              $('#discount').val(data.discount);
              $('#pricing').val(data.price);
            
          }
     })
    }
   
     $('#duration').on('change', function() { 
           data_fetch();
       });
// $('#discount').on('change', function() { 
//     percentage = $('#discount').val();
//   $percantageValue = percentage/100*$totalValue;
//   return round($totalValue-$percantageValue,2);
// })
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/admin/pricing.blade.php ENDPATH**/ ?>
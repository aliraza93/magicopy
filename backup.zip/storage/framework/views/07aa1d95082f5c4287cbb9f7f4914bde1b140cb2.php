
<?php $__env->startSection('content'); ?>
      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adstemplate','data' => ['adsinfo' => $adsinfo,'adscounter' => $adscounter,'user' => $user]]); ?>
<?php $component->withName('adstemplate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['adsinfo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adsinfo),'adscounter' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($adscounter),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/ads/template.blade.php ENDPATH**/ ?>
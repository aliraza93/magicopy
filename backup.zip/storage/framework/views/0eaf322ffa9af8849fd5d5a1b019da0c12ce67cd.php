<div>
    
    <!-- ========== Left Sidebar Start ========== -->
    <div class="left-side-menu">

        <div class="h-100" data-simplebar>

            <!-- User box  text-center -->
            <div class="user-box" style="margin-left:21px">
                
                <!--<div class="dropdown">-->
                    <!--<a href="javascript: void(0);" class="text-dark font-weight-normal dropdown-toggle h5 mt-2 mb-1 d-block"-->
                    <!--    data-toggle="dropdown"><?php echo e($user['username']); ?></a>-->
                <!--    <div class="dropdown-menu user-pro-dropdown">-->
                        <!-- item-->
                <!--        <a href="javascript:void(0);" class="dropdown-item notify-item">-->
                <!--            <i class="fe-user mr-1"></i>-->
                <!--            <span>My Account</span>-->
                <!--        </a>-->
                        <!-- item-->
                <!--        <a href="<?php echo e(url('logout')); ?>" class="dropdown-item notify-item">-->
                <!--            <i class="fe-log-out mr-1"></i>-->
                <!--            <span>Logout</span>-->
                <!--        </a>-->

                <!--    </div>-->
                <!--</div>-->
              
            </div>

            <!--- Sidemenu -->
            <div id="sidebar-menu">

                <ul id="side-menu">

                    
        
                    <li>
                        <a href="<?php echo e(url('dashboard')); ?>" style="color:<?php echo e(request()->is('dashboard')?'#FE5C5A':''); ?>"><i class="fab fa-dashcube"></i><span>Dashboard</span> </a>
                       
                    </li>
                    <li><a href="<?php echo e(url('users')); ?>" style="color:<?php echo e(request()->is('users')?'#FE5C5A':''); ?>"> <i class="fa fa-user" style="color: #3737aa;"></i> <span>Users</span> </a></li>
                    <li ><a href="<?php echo e(url('manage-page')); ?>" style="color:<?php echo e(request()->is('manage-page')?'#FE5C5A':''); ?>"> <i class="fa fa-file" ></i> <span>Manage page</span> </a></li>
                    <li><a href="<?php echo e(url('pricing')); ?>" style="color:<?php echo e(request()->is('pricing')?'#FE5C5A':''); ?>"> <i class="fas fa-dollar-sign" ></i> <span>Pricing</span> </a></li>
                     <li>
                        <a href="<?php echo e(url('logo/create')); ?>" style="color:<?php echo e(request()->is('logo/create')?'#FE5C5A':''); ?>"><i class="fas fa-image"></i><span>Logo</span> </a>
                         <a href="<?php echo e(url('g-tag')); ?>" style="color:<?php echo e(request()->is('g-tag')?'#FE5C5A':''); ?>"><i class="fas fa-tags"></i><span>G-tag</span> </a>
                       
                    </li>

                </ul>

            </div>
            <!-- End Sidebar -->

            <div class="clearfix"></div>

        </div>
        <!-- Sidebar -left -->
       
    </div>
    <!-- Left Sidebar End -->


</div><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/components/supeadmin_sidebar.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<style>
    .fkyVgZ {
    background-color: #FE6161;
    padding: 10px 40px;
    border: medium none;
    border-radius: 34px;
    box-shadow: rgba(83, 92, 165, 0.2) 0px 1px 2px 2px;
    color: white;
    font-size: 20px;
    margin-top: 30px;
}
</style>
    <!-- Form row -->
    <div class="row" style="margin-top: 3%;">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Profile</h4>
                    

                    <form action="<?php echo e(url('update/profile')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <p class="text-muted font-20">
                            Personal Information
                        </p>
                        <?php if(session('personalinfo')): ?>
                         <div class="alert alert-success"><?php echo e(session('personalinfo')); ?></div>
                        <?php endif; ?>
                        <div class="form-row">
                            
                            
                            <div class="form-group col-md-6">
                                <label for="firstname" class="col-form-label">First Name*</label>
                                <input type="text" class="form-control" id="firstname" name="fname" value="<?php echo e((!empty($profile['fname']) ? $profile['fname'] : '')); ?>" placeholder="First Name*" >
                                <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="lastname" class="col-form-label">Last Name*</label>
                                <input type="text" class="form-control" id="lastname" name="lname" value="<?php echo e((!empty($profile['lname']) ? $profile['lname'] : '')); ?>"  placeholder="Last Name*" >
                                <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4" class="col-form-label">User Name</label>
                                <input type="text" class="form-control" id="inputEmail4" name="username" value="<?php echo e((!empty($profile['username']) ? $profile['username'] : '')); ?>" placeholder="User Name">
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail4" class="col-form-label">Email</label>
                                <input type="email" class="form-control" id="inputEmail4" name="email" value="<?php echo e((!empty($profile['email']) ? $profile['email'] : '')); ?>" placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>      
                        </div>


                        <input type="submit" class="fkyVgZ" value="Update Profile" />

                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row -->

     <!-- Form row -->
     <div class="row" style="margin-top: 3%;">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                   
                    

                    <form action="<?php echo e(url('update/company_info')); ?>" method="POST">
                        <p class="text-muted font-20">
                            Company Information
                        </p>
                        <?php if(session('companyinfo')): ?>
                         <div class="alert alert-success"><?php echo e(session('companyinfo')); ?></div>
                        <?php endif; ?>
                        <div class="form-row">
                            
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-md-6">
                                <label for="company" class="col-form-label">Company*</label>
                                <input type="text" class="form-control" id="company" name="cmp_name" value="<?php echo e((!empty($profile['cmp_name']) ? $profile['cmp_name'] : '')); ?>" placeholder="Company*">
                                <?php $__errorArgs = ['cmp_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="description" class="col-form-label">Description*</label>
                                <textarea class="form-control" id="description"  name="cmp_description" placeholder="Description" rows="5"><?php echo e((!empty($profile['cmp_description']) ? $profile['cmp_description'] : '')); ?></textarea>
                                <?php $__errorArgs = ['cmp_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>    
                        </div>


                        <input type="submit" class="fkyVgZ" value="Update" />

                    </form>

                </div> <!-- end card-body -->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>
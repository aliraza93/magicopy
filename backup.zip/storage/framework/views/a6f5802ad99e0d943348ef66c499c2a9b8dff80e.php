<div>
    <style>
        .kajamm {
            background-color: white;
            width: 100%;
            padding: 20px;
            border-radius: 7px;
            user-select: none;
            margin-bottom: 20px;
        }
        .kypFeC {
            margin: 0px;
            font-size: 14px;
            color: rgb(33, 37, 41);
        }
        .gdARiY {
            color: rgb(28, 27, 168);
            font-size: 1.125rem;
        }
        p {
            margin-top: 0;
            margin-bottom: 1rem;
        }
    </style>
    <?php $__currentLoopData = $ads['choices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
   
    <div title="Relaxation Without The Cost" class="sc-citwmv kajamm">
        <p class="sc-jcVebW kypFeC"><b>Ad</b> • www.<?php echo e($ads['company_name']); ?>.com/ ▾<br>
        <div class="sc-iBaPrD gdARiY"><?php echo e($ads['company_name']); ?></div>
        <p><?php echo e($value['text']); ?>...</p>
        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/u644618368/domains/usemagicopy.com/public_html/resources/views/components/google_ad.blade.php ENDPATH**/ ?>
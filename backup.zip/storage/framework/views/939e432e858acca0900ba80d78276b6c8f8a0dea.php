<div>
    <style>
         @media  screen and (max-width: 1500px) and (min-width: 992px) {
            .nav > .nav-button {
                display: none;
            }
           
        }
        @media  screen and (max-width: 992px) {
            .nav-button {
                display: block;
            }
            .attr-nav{
                display: none;
            }
        }
    </style>
    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default attr-bg navbar-fixed dark no-background bootsnav">

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav light">
                    <ul>
                        <?php if($isLoggedIn==true && $user['role']='user'): ?>
                        <li class="button">
                            <a href="<?php echo e(route('template')); ?>">Dashboard</a>
                        </li>
                        <?php else: ?>
                        <li class="button" style="margin-right:4px">
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="button">
                            <a href="<?php echo e(url('register')); ?>">Register</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" class="logo" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
                        <li>
                            <a class="smooth-menu" href="#features">How it Works</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#overview">Features</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#team">Benefits</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#pricing">Pricing</a>
                        </li>
                        <?php if($isLoggedIn==true && $user['role']='user'): ?>
                        <li class="smooth-menu nav-button">
                            <a href="<?php echo e(route('template')); ?>">Dashboard</a>
                        </li>
                        <?php else: ?>
                        <li class="smooth-menu nav-button" style="margin-right:4px">
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="smooth-menu nav-button">
                            <a href="<?php echo e(url('register')); ?>">Register</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->
</div><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/components/userheader.blade.php ENDPATH**/ ?>
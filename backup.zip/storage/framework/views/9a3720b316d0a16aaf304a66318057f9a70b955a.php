
    <!-- ========== Left Sidebar Start ========== -->
    <div class="left-side-menu">

        <div class="h-100" data-simplebar>

            <!-- User box -->
            <div class="user-box text-center">
                <img src="<?php echo e(asset('assets')); ?>/admin/images/users/avatar.png" alt="user-img" title="Mat Helme"
                    class="rounded-circle avatar-md">
                <div class="dropdown">
                    <a href="javascript: void(0);" class="text-dark font-weight-normal dropdown-toggle h5 mt-2 mb-1 d-block"
                        data-toggle="dropdown"><?php echo e($user['username']); ?></a>
                    <div class="dropdown-menu user-pro-dropdown">

                        <!-- item-->
                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                            <i class="fe-user mr-1"></i>
                            <span>My Account</span>
                        </a>
                        <!-- item-->
                        <a href="<?php echo e(url('logout')); ?>" class="dropdown-item notify-item">
                            <i class="fe-log-out mr-1"></i>
                            <span>Logout</span>
                        </a>

                    </div>
                </div>
              
            </div>

            <!--- Sidemenu -->
            <div id="sidebar-menu">

                <ul id="side-menu">

                    
        
                    <li>
                        <a href="<?php echo e(url('dashboard')); ?>"><span>Dashboard</span> </a>
                       
                    </li>
                   
                   

                    <li><a href="javascript:void(0)" onclick="pageload('facebook-ads')"> <i class="fab fa-facebook" style="color: #3737aa;"></i> <span>Facebook Ad</span> </a></li>
                    <li><a href="javascript:void(0)" onclick="pageload('google-ads')"><i class="fab fa-google" style="color: #ff8227;"></i><span> Google Ad</span> </a></li>
                    <?php if(empty($user['subscriber'])): ?>
                     <li><a href="javascript:void(0)"> <i style="color: red;"><?php echo e($adscounter); ?></i> <span >&nbsp;credits left</span></a></li>
                    <?php endif; ?>
                    </ul>

            </div>
            <!-- End Sidebar -->

            <div class="clearfix"></div>

        </div>
        <!-- Sidebar -left -->
        <script type="text/javascript">

            function pageload(page){
                $url = "<?php echo e(url('/template')); ?>";
                token = $('input[name="_token"]').val();
                window.history.pushState("template", "Title", "<?php echo e(url('template')); ?>");
                $.ajax({
                  url: $url,
                  type: "POST",
                  dataType: 'json',
                  data: {_token: token,template:page},
                  success: function (data) {
                    if(data.response){
                        $('.list').find( 'li.active' ).removeClass( 'active' );
                        $('#'+data.pagename+'').addClass( 'active' );
                        $('.templatediv').html(data.page);
                    }
                    else{
                        alert('Something Went Wrong');
                    }
                  }
                });
            };
            
            </script>
    </div>
    <!-- Left Sidebar End -->

<?php /**PATH E:\xammp\htdocs\copysmith\resources\views/components/admin_sidebar.blade.php ENDPATH**/ ?>
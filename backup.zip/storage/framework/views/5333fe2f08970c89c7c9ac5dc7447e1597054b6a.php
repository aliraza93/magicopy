
<?php $__env->startSection('content'); ?>
<style>
    .error{
        color: red
    }
</style>
<div class="account-pages mt-5 mb-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card bg-pattern">

                    <div class="card-body p-4">
                        
                        <div class="text-center w-75 m-auto">
                            <div class="auth-logo">
                                <a href="<?php echo e(url('/')); ?>" class="logo logo-dark text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" height="22">
                                    </span>
                                </a>
            
                                <a href="<?php echo e(url('/')); ?>" class="logo logo-light text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('assets')); ?>/frontend/img/logo.png" alt="" height="22">
                                    </span>
                                </a>
                            </div>
                            <p class="text-muted mb-4 mt-3">Enter your email address and password to access admin panel.</p>
                        </div>
                        <?php if(session('changepassword')): ?>
                        <div class="alert alert-danger"><?php echo e(session('changepassword')); ?> </div>
                        <?php endif; ?>
                        <?php if(session('message')): ?>
                        <div class="alert alert-<?php echo e(session('message')=='You Are Not Allowed To Perform This Action!' ? 'danger' : 'success'); ?>"><?php echo e(session('message')); ?></div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        <form action="<?php echo e(url('login')); ?>" enctype="multipart/form-data" method="POST" >
                             <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="emailaddress">Email address</label>
                                <input class="form-control" type="email" id="emailaddress" name="email"  placeholder="Enter your email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <label for="password">Password</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control" name="password" placeholder="Enter your password">
                                    <div class="input-group-append" data-password="false">
                                        <div class="input-group-text">
                                            <span class="fa fa-eye font-12"></span>
                                        </div>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="error"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked>
                                    <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                                </div>
                            </div>

                            <div class="form-group mb-0 text-center">
                                <button class="btn btn-primary btn-block" style="background-color: #FE6161" type="submit"> Log In </button>
                            </div>

                        </form>

                        

                    </div> <!-- end card-body -->
                </div>
                <!-- end card -->

                <div class="row mt-3">
                    <div class="col-12 text-center">
                        <p> <a href="<?php echo e(route('password-recover')); ?>" class="text-white-50 ml-1">Forgot your password?</a></p>
                        <p class="text-white-50">Don't have an account? <a href="<?php echo e(url('register')); ?>" class="text-white ml-1"><b>Sign Up</b></a></p>
                    </div> <!-- end col -->
                </div>
                <!-- end row -->

            </div> <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</div>
<!-- end page -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/adminlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/admin/user/login.blade.php ENDPATH**/ ?>
<div>
    <style>
        .cmuvkJ {
            border-radius: 15px;
            border: 2px solid rgb(132, 141, 211);
            margin: 20px;
            display: inline-block;
            position: relative;
            cursor: pointer;
            width: 248px;
            height: 176px;
        }
        .esbyIi {
            position: absolute;
            left: 50%;
            display: inline-block;
            top: 50%;
            transform: translate(-50%, -50%);
            color: rgb(83, 92, 165);
            text-align: center;
            width: 100%;
        }
    </style>
    <?php if($adscounter >0 && empty($user['subscription']['status']) || !empty($user['subscription']['status']) && $user['subscription']['status']=='active'): ?>
        <a href="<?php echo e(!empty($url)?url($url):url('facebook-ad')); ?>">
            <div class="sc-iWFSnp cmuvkJ">
                <div class="sc-dRPiIx esbyIi">
                    <div style="font-size: 45px;">+</div>
                    <div>New <?php echo e(!empty($tempname)?$tempname:'facebook'); ?> Ad </div>
                </div>
            </div>
       </a>
    
  <?php endif; ?>
   <?php $__currentLoopData = $adsinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <a href="<?php echo e(!empty($url)?url($url.'/'.$value['company_name'].'/'.encrypt($value['id'])):url('facebook-ad/'.$value['company_name'].'/'.encrypt($value['id']).'')); ?>">
        <div class="sc-iWFSnp cmuvkJ">
            <div class="sc-dRPiIx esbyIi">
                <div style="font-size: 26px;"><?php echo e($value['company_name']); ?></div>
                <div style="bottom: 10px; left: 20px;"><?php echo e(date('Y-m-d ',strtotime($value['created_at']))); ?></div>
            </div>
        </div>
    </a>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH E:\xammp\htdocs\copysmith\resources\views/components/adstemplate.blade.php ENDPATH**/ ?>
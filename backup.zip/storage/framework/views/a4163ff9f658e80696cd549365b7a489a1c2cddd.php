
<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top:3%">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if(!empty(session('message'))): ?>
                  <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>
                <h5>Main Content</h5>
                <form action="" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <?php
                      $main_content_text = json_decode($page_content->main_content);
                    ?>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-primary">
                            <input type="radio" name="main_content_display" value="true" <?php echo e($main_content_text->main_content_display=='true'?'checked':''); ?> <?php if(old('main_content_display')): ?> checked <?php endif; ?>> Show
                        </label>
                    </div>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-secondary">
                            <input type="radio" name="main_content_display" value="false" <?php echo e($main_content_text->main_content_display=='true'?'false':''); ?>  <?php if(old('main_content_display')): ?> checked <?php endif; ?>> Hide
                        </label>
                    </div>
                    
                </div>
                <div class="form-group">
                    <label for="my-input">Heading</label>
                    <input id="my-input" class="form-control" type="text" value="<?php echo e($main_content_text->main_content_heading); ?>" name="main_content_heading"/>
                </div>
                <div class="form-group">
                    <label for="my-input">text</label>
                    <textarea id="my-input" class="form-control" type="text" name="main_content_text"  cols="30" rows="10"><?php echo e($main_content_text->main_content_text); ?></textarea>
                </div>
                <h5>content 1</h5>
                <div class="form-group">
                    <?php
                      $content1 = json_decode($page_content->content1);
                    ?>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-primary">
                            <input type="radio" name="content1_display" value="true" <?php echo e($main_content_text->main_content_display=='true'?'checked':''); ?> <?php if(old('main_content_display')): ?> checked <?php endif; ?>> Show
                        </label>
                    </div>
                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                        <label class="btn btn-secondary">
                            <input type="radio" name="content1_display" value="false" <?php echo e($main_content_text->main_content_display=='true'?'false':''); ?>  <?php if(old('main_content_display')): ?> checked <?php endif; ?>> Hide
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="my-input">Heading</label>
                    <input id="my-input" class="form-control" type="text" value="<?php echo e($main_content_text->main_content_heading); ?>" name="content1_heading"/>
                </div>
                <div class="form-group">
                    <label for="my-input">text</label>
                    <textarea id="my-input" class="form-control" type="text" name="content1_text"  cols="30" rows="10"><?php echo e($main_content_text->main_content_text); ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/admin/admin/manage_page.blade.php ENDPATH**/ ?>
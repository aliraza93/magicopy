
<?php $__env->startSection('content'); ?>
      <?php if (isset($component)) { $__componentOriginal937f798e04df8d349c291ffa1c2b61fbca393690 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Adstemplate::class, ['adsinfo' => $adsinfo,'adscounter' => $adscounter,'user' => $user]); ?>
<?php $component->withName('adstemplate'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal937f798e04df8d349c291ffa1c2b61fbca393690)): ?>
<?php $component = $__componentOriginal937f798e04df8d349c291ffa1c2b61fbca393690; ?>
<?php unset($__componentOriginal937f798e04df8d349c291ffa1c2b61fbca393690); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xammp\htdocs\copysmith\resources\views/admin/ads/template.blade.php ENDPATH**/ ?>
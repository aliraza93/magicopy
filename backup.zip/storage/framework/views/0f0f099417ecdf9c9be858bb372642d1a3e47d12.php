<?php $__env->startSection('content'); ?>
<style>
    .col-6,.col-4 {
        border: 1px solid;
    }
    .logo_div{
         width:50%;
         margin: auto;"
    }
    @media  screen and (max-width: 992px) {
      .logo_div{
       width:100%;
      }
    }
</style>
<div class="row logo_div">
    <div class="col-12">
        <div class="card" style="margin-top: 30px;">
            <div class="card-body">
                
                <h2 style="text-align:center;margin-right: 69px;color: #fe5c5a;">Upload MegiCopy Logo</h2>
                   <?php if(session('message')): ?>
                   <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                   <?php endif; ?>
                    <form action="<?php echo e(url('logo/create')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <div class="col-12">
                        <div class="form-group">
                                <label for="my-input">Upload Logo</label>
                                <input id="my-input" class="form-control-file btn btn-danger" type="file" name="file"  required>
                              <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                         <div class="row mb-4">
                                <?php if(!empty($logo->file)): ?>
                                
                              
                                    <img style="    
                                    width: 94%;
    object-fit: contain;
    border-radius: 15px;
    box-shadow: 1px 2px 15px -5px #000000b3;
    background: white;
    margin: 20px;
    display: inline-block;
    position: relative;" src="<?php echo e(asset('public/assets/page-content')); ?>/<?php echo e($logo->file); ?>" alt="no image">
                               
                                
                                <?php endif; ?>
                         </div>
                         <div class="form-group" style="text-align: center;margin-top: 24px;">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </form>
               
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u153436862/domains/techuire.com/public_html/demo/magicopy/resources/views/admin/admin/logo.blade.php ENDPATH**/ ?>